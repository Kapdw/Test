import { useEffect, useState } from 'react'
import './App.css'
import axios from 'axios'

function App() {
  const [pokemons, setPokemons] = useState([]);
  const [page, setPage] = useState(1);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    setLoading(true)
    let newPokemons = [];
    let pageItemsNumber = 10;
    axios.get(`https://pokeapi.co/api/v2/pokemon?limit=${pageItemsNumber}&offset=${page * pageItemsNumber - pageItemsNumber}`)
      .then(async response => {
        let promises = [];
        for (let pokemon of response.data.results) {
          promises.push(axios.get(pokemon.url).then(response => {
            newPokemons.push(response.data)
          }))
        };
        await Promise.all(promises);
        setPokemons(newPokemons)
        setLoading(false)
      })
      .catch(error => {
        console.log(error);
      })
  }, [page])


  return (
    <>
      <h1>PokeAPI</h1>
      <div className='pokemons'>
        {pokemons.map((pokemon, index) => {
          return (
            <div key={index}>
              <h2>{pokemon.name}</h2>
              <img src={pokemon.sprites.front_default} alt={pokemon.name} />
            </div>
          )
        })}
      </div>
      <div className='pages'>
        <button onClick={() => setPage(page - 1)} disabled={page === 1}>Previous</button>
        <p>{page}</p>
        <button onClick={() => setPage(page + 1)}>Next</button>
        {loading && <p>Loading...</p>}
      </div>
    </>
  )
}

export default App

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mon espace</title>
    <link rel="stylesheet" href="espace.css">
    <script src="https://unpkg.com/axios/dist/axios.min.js"></script>
</head>
<body>
    <header>
       <h1>Mon espace</h1>
    </header>
    <?php
    require __DIR__ . './db.php';
    session_start();
    $user_id = $_SESSION['id'];
    $tg = " SELECT * From livre, favori where favori.id_utilisateur = '$user_id' and favori.id_livre = livre.id" ?>
    <h2>nom : <?= htmlspecialchars($_SESSION['name']) ?></h2>
    <h2>mail : <?= htmlspecialchars($_SESSION['email']) ?></h2>
    <a href="password.php">Changement de mot de passe</a>
    <h2> Mes Livre : </h2>
    <script src="app.js" defer></script>
    <script defer>getFavori()</script>
    <div class="in">
       <div class='cards'>

        </div>
    </div>   
</body>
</html>
const search = document.querySelector('.search');
let api = `https://www.googleapis.com/books/v1/volumes?q=`;
const btn = document.querySelector('.button');
btn.addEventListener('click', () => getData());

function getData() {
    let key = search.value;
    if (key == "") {
        return;
    }

    axios.get(api + key)
        .then((data) => {
            let items = data.data.items;
            displayChars(items)
        })
}

function displayChars(data) {
    document.querySelector(".cards").innerHTML=""
    data.forEach(item => {
        console.log(item)
        let book = document.createElement('div')
        book.className = 'card'
        book.innerHTML = `
                            <div>
                            <h2 class='name'>${item.volumeInfo.title}</h2>  
                            <h3 class='films'>Auteur : ${item.volumeInfo.authors}</h3> 
                            <img src='${item.volumeInfo.imageLinks ? item.volumeInfo.imageLinks.thumbnail : "./cou2.png"}'/> 
                            <input type="submit" class="fav" onclick="toggleFavorite('${item.id}')" value="validez">
                            </div>
                            `
        document.querySelector('.cards').appendChild(book)
    })
};
const fav = document.querySelector('.fav');
function toggleFavorite(id ){

    axios.get(`favoris.php?id=${id}`);
}
function getFavori(){
    axios.get('favoris.php').then((data) => {
        let items = data.data.items;
        displayChars(items)
    });
}
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="signup.css">
</head>
<body>
    
<header>
    <div class="head">
        <h1>KerBook</h1>
    <a href="index.php"><h1>ACCUEIL</h1></a>
    </div>
</header>
<div class="dedans">
    <div class="totu">
        <br>
        <br>
    <form action="loginprocess.php" method="post">
    <label for="email">Votre adresse mail</label>
    <input type="email" name="email" placeholder="votre email">
    <br>
    <br>
    <label for="pass">Votre mot de passe</label>
    <input type="password" name="password" placeholder="mot de passe">

    <button class="btn submit">Envoyer</button>
    </div>
</div>
</form>
</body>
</html>
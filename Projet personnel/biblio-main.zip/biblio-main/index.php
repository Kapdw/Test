<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Accueil</title>
    <link rel="stylesheet" href="biblio.css">
    <script src="app.js" defer></script>
    <script src="https://unpkg.com/axios/dist/axios.min.js"></script>
</head>
<body>
    <header>
        <h1>KerBook</h1>
        <div class="searchbar">
        <input class="search" type="text" placeholder="Recherche"><input class="button" type="button">
        </div>
    </header>
    <nav>
        <div class="fuk">
          <a href="index.php">Accueil</a>
            <?php 
            session_start();
            if(!isset($_SESSION['name'])):
            ?>
            <a class="login" href="login.php">Login</a>
            <a class="signup" href="signup.php">Sign up</a>
            <?php else:?>
    <a href="monespace.php"><?= htmlspecialchars($_SESSION['name']) ?></a>
    <a href="logout.php" class='btn-logout'>Se déconnecter</a>
    <?php endif ?>
        </div>
    </nav>
    <div class="in">
       <div class='cards'>

        </div>
    </div>   
</body>
</html>


<?php
require __DIR__. './db.php';
session_start();
$id = $_SESSION["id"];
$old = $_POST['oldpassword'];
$requeste = "SELECT password FROM utilisateur WHERE id=$id";
$data = $mysqli->query($requeste)->fetch();
$password = $data['password'];
if (password_verify($old, $password)){
    die('mot de passe incorrecte');
}
if ($_POST['newpassword'] == $_POST['password'] && strlen($_POST['newpassword']) <= 8  ){
    die("le mot de passe doit contenir au moins 8 caractères et doit etre different de l'ancien");
}
if ($_POST['newpassword'] != $_POST['password_chek']){
    die('le nouveau mot de passe est incorrecte');
}
$hash = password_hash($_POST['newpassword'], PASSWORD_DEFAULT);
$req = "UPDATE utilisateur set password = $hash where id = $id ";
$stmt = $mysqli->stmt_init();

// On prépare la requete
$stmt->prepare($req);
$stmt->execute();

header('location: index.php');
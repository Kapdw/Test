<?php
require __DIR__. './db.php';
session_start();
$livre_id = $_GET['id'];
$user_id = $_SESSION['id'];
$verif ="";
$req = 'INSERT INTO favori(id_livre, id_utilisateur)VALUES ("$livre_id","$user_id")';
$res = mysqli_query($mysqli,$req);

$url="https://www.googleapis.com/books/v1/volumes/$livre_id";
$curl = curl_init($url);
curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
$response = curl_exec($curl);
if(curl_error($curl)){
    echo 'Error: ' . curl_error($curl);
}
$decoded = json_decode($response, true);
$titre = $decoded['volumeInfo']['title'];
$author = $decoded['volumeInfo']['authors'];
$image = isset($decoded['volumeInfo']['imageLinks']) ? $decoded['volumeInfo']['imageLinks']['thumbnail'] : "./cou2.png";

curl_close($curl);

$req2 = "INSERT INTO livre (id, nom, author, image) VALUES ('$livre_id', '$titre', '$author[0]', '$image')";
$res2 = mysqli_query($mysqli, $req2);
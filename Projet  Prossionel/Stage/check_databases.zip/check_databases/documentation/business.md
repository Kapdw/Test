# Documentation des fonctions

## Fichier check.js

### Fonction checkExists(customers, fields, range, error, location)

Cette fonction vérifie si les valeurs des champs spécifiés existent dans la liste de clients donnée. Elle prend les paramètres suivants :

-   `customers` : Liste des clients
-   `fields` : Liste des champs à vérifier
-   `range` : Plage de valeurs attendue
-   `error` : Message d'erreur en cas de champ manquant
-   `location` : Tableau des codes de localisation

La fonction utilise la fonction `getFieldValue` pour obtenir les valeurs des champs. Cette fonction se base sur les fonctions `getLocationFirstValue` et `getLocationSecondValue` pour récupérer les codes de localisation (`pointcode` et `categorycode`). Les valeurs des champs sont ensuite vérifiées, et un tableau d'erreurs est renvoyé si des problèmes sont détectés. En cas de succès, la fonction renvoie un objet `success`.

### Fonction checkBetween(customers, fields, range, error, location)

Cette fonction vérifie si les valeurs des champs spécifiés sont comprises dans une plage de valeurs donnée. Elle prend les paramètres suivants :

-   `customers` : Liste des clients
-   `fields` : Liste des champs à vérifier
-   `range` : Plage de valeurs attendue
-   `error` : Message d'erreur en cas de champ manquant
-   `location` : Tableau des codes de localisation

La fonction utilise la fonction `getFieldValue` pour obtenir les valeurs des champs. Cette fonction se base sur les fonctions `getLocationFirstValue` et `getLocationSecondValue` pour récupérer les codes de localisation (`pointcode` et `categorycode`). Les valeurs des champs sont ensuite vérifiées, et un tableau d'erreurs est renvoyé si des problèmes sont détectés. En cas de succès, la fonction renvoie un objet `success`.

### Fonction checkValue(customers, fields, range, error, location)

Cette fonction vérifie si les valeurs des champs spécifiés correspondent à une valeur exacte ou à un ensemble de valeurs donné. Elle prend les paramètres suivants :

-   `customers` : Liste des clients
-   `fields` : Liste des champs à vérifier
-   `range` : Plage de valeurs attendue
-   `error` : Message d'erreur en cas de champ manquant
-   `location` : Tableau des codes de localisation

La fonction utilise la fonction `getFieldValue` pour obtenir les valeurs des champs. Cette fonction se base sur les fonctions `getLocationFirstValue` et `getLocationSecondValue` pour récupérer les codes de localisation (`pointcode` et `categorycode`). Les valeurs des champs sont ensuite vérifiées, et un tableau d'erreurs est renvoyé si des problèmes sont détectés. En cas de succès, la fonction renvoie un objet `success`.

## Fichier common.js

### Fonction getFieldValue(customers, fields, pc, cc, error)

Cette fonction permet de récupérer les valeurs des champs spécifiés dans une liste de clients, ainsi que les codes de point et de catégorie associés. Elle prend les paramètres suivants :

-   `customers` : Liste des clients
-   `fields` : Liste des champs à récupérer
-   `pc` : Code de point
-   `cc` : Code de catégorie
-   `error` : Message d'erreur en cas de champ manquant

La fonction utilise les fonctions `getLocationFirstValue` et `getLocationSecondValue` pour obtenir les codes de point et de catégorie à partir des valeurs des champs. Les valeurs des champs sont vérifiées et des résultats sont renvoyés. L'objet retourné par la fonction contient les valeurs des champs (`fieldValues`), les codes de point (`pointcodes`), les codes de catégorie (`categorycodes`) et les résultats des vérifications (`results`).

### Fonction getLocationFirstValue(fieldValue, point_code, error)

Cette fonction permet de récupérer la valeur du code de point à partir d'une valeur de champ donnée. Elle prend les paramètres suivants :

-   `fieldValue` : Valeur du champ
-   `point_code` : Code de point
-   `error` : Message d'erreur en cas de champ manquant

La fonction retourne un objet contenant la valeur du code de point (`pointcode`) et les avertissements éventuels (`warning`).

### Fonction getLocationSecondValue(fieldValue, category_code, error)

Cette fonction permet de récupérer la valeur du code de catégorie à partir d'une valeur de champ donnée. Elle prend les paramètres suivants :

-   `fieldValue` : Valeur du champ
-   `category_code` : Code de catégorie
-   `error` : Message d'erreur en cas de champ manquant

La fonction retourne un objet contenant la valeur du code de catégorie (`categorycode`) et les avertissements éventuels (`warnings`).

## Fichier compare.js

### Fonction compare(customers, fields, range, error, location, compare)

Cette fonction compare les valeurs des champs spécifiés entre deux listes de clients. Elle utilise la fonction `getFieldValue` pour récupérer les valeurs des champs dans les deux listes de clients. Elle prend les paramètres suivants :

-   `customers` : Liste des clients à comparer
-   `fields` : Liste des champs à comparer
-   `range` : Plage de valeurs attendue
-   `error` : Message d'erreur en cas de champ manquant
-   `location` : Tableau des codes de localisation
-   `compare` : Liste des clients à comparer avec la première liste

La fonction commence par vérifier si les données fournies sont valides. Si des données invalides sont détectées, elle renvoie un objet contenant un message d'erreur.

Ensuite, elle utilise la fonction `getFieldValue` pour obtenir les valeurs des champs dans les deux listes de clients. Les valeurs des champs, ainsi que les codes de point et de catégorie correspondants, sont extraites à l'aide de la destructuration.

La fonction vérifie si des erreurs ont été détectées lors de l'appel à `getFieldValue`. Si des erreurs sont présentes, elles sont ajoutées au tableau de résultats.

Sinon, la fonction itère sur les valeurs des champs de la première liste de clients. Pour chaque valeur de champ, elle vérifie si elle existe dans la liste des valeurs de champ de la deuxième liste de clients. Si une valeur de champ n'est pas présente, une erreur est ajoutée au tableau de résultats.

Enfin, la fonction vérifie si des erreurs ont été détectées. Si des erreurs sont présentes, elle renvoie le tableau de résultats. Sinon, elle renvoie un objet `success` pour indiquer que la comparaison s'est terminée avec succès.

## Fichier contain.js

### Fonction contains(customers, fields, range, error, location)

Cette fonction vérifie si les valeurs des champs spécifiés contiennent un caractère spécifique dans une liste de clients. Elle utilise la fonction `getFieldValue` pour récupérer les valeurs des champs dans la liste de clients. Elle prend les paramètres suivants :

-   `customers` : Liste des clients à vérifier
-   `fields` : Liste des champs à vérifier
-   `range` : Plage de valeurs attendue
-   `error` : Message d'erreur en cas de champ manquant
-   `location` : Tableau des codes de localisation

La fonction commence par vérifier si les données fournies sont valides. Si des données invalides sont détectées, elle renvoie un objet contenant un message d'erreur.

Ensuite, elle utilise la fonction `getFieldValue` pour obtenir les valeurs des champs dans la liste de clients. Les valeurs des champs, ainsi que les codes de point et de catégorie correspondants, sont extraites à l'aide de la destructuration.

La fonction vérifie si des erreurs ont été détectées lors de l'appel à `getFieldValue`. Si des erreurs sont présentes, elles sont ajoutées au tableau de résultats.

Sinon, la fonction itère sur les valeurs des champs et vérifie si elles contiennent le caractère spécifié dans la plage de valeurs attendue. Si une valeur de champ ne contient pas le caractère, une erreur est ajoutée au tableau de résultats.

Enfin, la fonction vérifie si des erreurs ont été détectées. Si des erreurs sont présentes, elle renvoie le tableau de résultats. Sinon, elle renvoie un objet `success` pour indiquer que la vérification s'est terminée avec succès.

### Fonction isEmpty(customers, fields, range, error, location)

Cette fonction vérifie si les valeurs des champs spécifiés sont vides dans une liste de clients. Elle utilise la fonction `getFieldValue` pour récupérer les valeurs des champs dans la liste de clients. Elle prend les paramètres suivants :

-   `customers` : Liste des clients à vérifier
-   `fields` : Liste des champs à vérifier
-   `range` : Plage de valeurs attendue
-   `error` : Message d'erreur en cas de champ manquant
-   `location` : Tableau des codes de localisation

La fonction commence par vérifier si les données fournies sont valides. Si des données invalides sont détectées, elle renvoie un objet contenant un message d'erreur.

Ensuite, elle utilise la fonction `getFieldValue` pour obtenir les valeurs des champs dans la liste de clients. Les valeurs des champs, ainsi que les codes de point et de catégorie correspondants, sont extraites à l'aide de la destructuration.

La fonction vérifie si des erreurs ont été détectées lors de l'appel à `getFieldValue`. Si des erreurs sont présentes, elles sont ajoutées au tableau de résultats.

Sinon, la fonction itère sur les valeurs des champs et vérifie si elles sont vides. Si une valeur de champ est vide, une erreur est ajoutée au tableau de résultats.

Enfin, la fonction vérifie si des erreurs ont été détectées. Si des erreurs sont présentes, elle renvoie le tableau de résultats. Sinon, elle renvoie un objet `success` pour indiquer que la vérification s'est terminée avec succès.

## Fichier dataProcessing.js

### Fonction processResponse(response, waydata, compared)

Cette fonction traite la réponse obtenue et effectue les vérifications spécifiées dans les données de chemin (`waydata`). Elle utilise également une comparaison de données si elle est fournie. Elle prend les paramètres suivants :

-   `response` : Réponse obtenue
-   `waydata` : Données de chemin contenant les conditions, les champs, la plage de valeurs, les erreurs, la localisation et le rôle
-   `compared` : Données de comparaison facultatives

La fonction commence par extraire les clients de la réponse et les données de chemin à partir des paramètres. Elle vérifie également si les conditions spécifiées sont valides.

Ensuite, la fonction crée un objet `conditions` qui associe chaque condition à sa fonction correspondante. Les conditions comprennent la vérification entre deux valeurs, l'existence d'une valeur, la validation JSON, la validation du nombre, la validation de la chaîne de caractères, la validation booléenne, la validation du tableau, la vérification de l'égalité, la vérification de la présence d'un caractère, la vérification si une valeur est vide et la comparaison de données.

Si une comparaison est fournie, la fonction vérifie si la condition spécifiée existe dans l'objet `conditions`. Si la condition est valide, la fonction correspondante est appelée avec les clients, les champs, la plage de valeurs, les erreurs et la comparaison. Le résultat de la vérification est renvoyé avec le rôle associé.

Si aucune comparaison n'est fournie, la fonction vérifie si la condition spécifiée existe dans l'objet `conditions`. Si la condition est valide, la fonction correspondante est appelée avec les clients, les champs, la plage de valeurs et les erreurs. Le résultat de la vérification est renvoyé avec le rôle associé.

En cas d'erreur lors de la vérification des données, la fonction capture l'erreur et renvoie un objet contenant le message d'erreur.

### Fonction filterResult(results)

Cette fonction filtre les résultats obtenus après le traitement des réponses. Elle prend les résultats bruts et les transforme en un format de tableau de résultats plus lisible et compréhensible. Elle prend les paramètres suivants :

-   `results` : Résultats bruts obtenus après le traitement des réponses

La fonction commence par aplatir les résultats en un tableau unique et supprime les résultats vides. Ensuite, elle itère sur les résultats et les transforme en un format de tableau plus lisible.

Enfin, la fonction renvoie le tableau de résultats filtré.

### Fonction processResults(responses, waydata, compares)

Cette fonction traite les réponses obtenues et effectue les vérifications spécifiées dans les données de chemin (`waydata`). Elle utilise également des comparaisons de données si elles sont fournies. Elle prend les paramètres suivants :

-   `responses` : Réponses obtenues
-   `waydata` : Données de chemin contenant les conditions, les champs, la plage de valeurs, les erreurs, la localisation et le rôle
-   `compares` : Comparaisons de données facultatives

La fonction utilise `Promise.all` pour traiter les réponses de manière asynchrone. Elle itère sur les réponses et les données de chemin et appelle la fonction `processResponse` pour effectuer les vérifications. Si des comparaisons sont fournies, elle les inclut également dans le traitement.

Enfin, la fonction renvoie une promesse résolue avec les résultats obtenus après le traitement.

## Fichier dataType.js

### Fonction isNumber(customers, fields, range, error, location)

Cette fonction vérifie si les valeurs des champs spécifiés dans `customers` et `fields` sont des nombres. Elle prend les paramètres suivants :

-   `customers` : Liste des clients
-   `fields` : Liste des champs à vérifier
-   `range` : Plage de valeurs autorisées
-   `error` : Message d'erreur à afficher en cas d'échec de validation
-   `location` : Coordonnées de localisation des données à vérifier

La fonction commence par vérifier si les données sont valides (non nulles et non vides). Ensuite, elle utilise la fonction `getFieldValue` pour obtenir les valeurs des champs spécifiés.

La fonction itère sur les valeurs des champs et effectue les vérifications suivantes :

-   Si la valeur n'est ni un nombre ni une chaîne de caractères, une erreur est ajoutée aux résultats avec les détails de la valeur, le type reçu et le type attendu.
-   Si la valeur est une chaîne de caractères, mais ne peut pas être convertie en nombre, une erreur est ajoutée aux résultats avec les détails de la valeur et une indication de conversion invalide.

Si des erreurs sont détectées, elles sont ajoutées aux résultats. Sinon, un objet `{ success: true }` est renvoyé pour indiquer que la validation a réussi.

### Fonction isString(customers, fields, range, error, location)

Cette fonction vérifie si les valeurs des champs spécifiés dans `customers` et `fields` sont des chaînes de caractères. Elle prend les paramètres suivants :

-   `customers` : Liste des clients
-   `fields` : Liste des champs à vérifier
-   `range` : Plage de valeurs autorisées
-   `error` : Message d'erreur à afficher en cas d'échec de validation
-   `location` : Coordonnées de localisation des données à vérifier

La fonction commence par vérifier si les données sont valides (non nulles et non vides). Ensuite, elle utilise la fonction `getFieldValue` pour obtenir les valeurs des champs spécifiés.

La fonction itère sur les valeurs des champs et effectue les vérifications suivantes :

-   Si la valeur n'est pas une chaîne de caractères, une erreur est ajoutée aux résultats avec les détails de la valeur, le type reçu et le type attendu.

Si des erreurs sont détectées, elles sont ajoutées aux résultats. Sinon, un objet `{ success: true }` est renvoyé pour indiquer que la validation a réussi.

### Fonction isBoolean(customers, fields, range, error, location)

Cette fonction vérifie si les valeurs des champs spécifiés dans `customers` et `fields` sont des booléens. Elle prend les paramètres suivants :

-   `customers` : Liste des clients
-   `fields` : Liste des champs à vérifier
-   `range` : Plage de valeurs autorisées
-   `error` : Message d'erreur à afficher en cas d'échec de validation
-   `location` : Coordonnées de localisation des données à vérifier

La fonction commence par vérifier si les données sont valides (non nulles et non vides). Ensuite, elle utilise la fonction `getFieldValue` pour obtenir les valeurs des champs spécifiés.

La fonction itère sur les valeurs des champs et effectue les vérifications suivantes :

-   Si la valeur n'est ni un booléen ni une chaîne de caractères, une erreur est ajoutée aux résultats avec les détails de la valeur, le type reçu et le type attendu.
-   Si la valeur est une chaîne de caractères, elle est convertie en minuscules. Si la valeur n'est ni "true" ni "false", une erreur est ajoutée aux résultats avec les détails de la valeur et une indication de valeur booléenne invalide.

Si des erreurs sont détectées, elles sont ajoutées aux résultats. Sinon, un objet `{ success: true }` est renvoyé pour indiquer que la validation a réussi.

### Fonction isArray(customers, fields, range, error, location)

Cette fonction vérifie si les valeurs des champs spécifiés dans `customers` et `fields` sont des tableaux. Elle prend les paramètres suivants :

-   `customers` : Liste des clients
-   `fields` : Liste des champs à vérifier
-   `range` : Plage de valeurs autorisées
-   `error` : Message d'erreur à afficher en cas d'échec de validation
-   `location` : Coordonnées de localisation des données à vérifier

La fonction commence par vérifier si les données sont valides (non nulles et non vides). Ensuite, elle utilise la fonction `getFieldValue` pour obtenir les valeurs des champs spécifiés.

La fonction itère sur les valeurs des champs et effectue les vérifications suivantes :

-   Si la valeur n'est ni une chaîne de caractères ni un tableau, une erreur est ajoutée aux résultats avec les détails de la valeur, le type reçu et le type attendu.
-   Si la valeur est une chaîne de caractères, elle est analysée en tant que JSON. Si l'analyse échoue ou le résultat n'est pas un tableau, une erreur est ajoutée aux résultats avec les détails de la valeur et une indication de conversion de tableau invalide.

Si des erreurs sont détectées, elles sont ajoutées aux résultats. Sinon, un objet `{ success: true }` est renvoyé pour indiquer que la validation a réussi.

### Fonction isJson(customers, fields, range, error, location)

Cette fonction vérifie si les valeurs des champs spécifiés dans `customers` et `fields` sont des objets JSON valides. Elle prend les paramètres suivants :

-   `customers` : Liste des clients
-   `fields` : Liste des champs à vérifier
-   `range` : Plage de valeurs autorisées
-   `error` : Message d'erreur à afficher en cas d'échec de validation
-   `location` : Coordonnées de localisation des données à vérifier

La fonction commence par vérifier si les données sont valides (non nulles et non vides). Ensuite, elle utilise la fonction `getFieldValue` pour obtenir les valeurs des champs spécifiés.

La fonction itère sur les valeurs des champs et effectue les vérifications suivantes :

-   Si la valeur n'est ni un objet ni une chaîne de caractères, une erreur est ajoutée aux résultats avec les détails de la valeur, le type reçu et le type attendu.
-   Si la valeur est une chaîne de caractères, elle est analysée en tant que JSON. Si l'analyse échoue, une erreur est ajoutée aux résultats avec les détails de la valeur et une indication de format JSON invalide.
-   Si la valeur est un objet, il est converti en JSON et ensuite analysé. Si l'analyse échoue, une erreur est ajoutée aux résultats avec les détails de la valeur et une indication de format JSON invalide.

Si des erreurs sont détectées, elles sont ajoutées aux résultats. Sinon, un objet `{ success: true }` est renvoyé pour indiquer que la validation a réussi.

## Fichier mail.js

### Classe HttpApiV2

La classe `HttpApiV2` est importée à partir du module `nodelib` et est utilisée pour effectuer des requêtes HTTP. Aucune autre information n'est disponible sur cette classe dans le code fourni.

### Fonction sendMailWithTemplate

La fonction `sendMailWithTemplate` permet d'envoyer un e-mail en utilisant un modèle prédéfini. Elle prend les paramètres suivants :

-   `emailDest` : L'adresse e-mail de destination.
-   `emailFrom` : L'adresse e-mail de l'expéditeur.
-   `template` : Le nom du modèle de courrier électronique à utiliser.
-   `data` : Les données à inclure dans le modèle de courrier électronique.
-   `attachmentName` : Le nom de la pièce jointe (facultatif).
-   `attachmentContent` : Le contenu de la pièce jointe (facultatif).

La fonction commence par construire l'URL du service de génération de documents en concaténant la variable d'environnement `DOCGEN_URL` avec le chemin `/email/` et le nom du modèle. Ensuite, elle crée un objet `bodyData` contenant les données à envoyer avec la requête.

La fonction envoie une requête POST à l'URL du service de génération de documents en utilisant la bibliothèque `http` importée précédemment. Les données sont envoyées dans le corps de la requête.

Ensuite, la fonction construit l'URL du service de messagerie en concaténant la variable d'environnement `MAILER_URL` avec le chemin `/mail`. Si des pièces jointes sont spécifiées, elles sont ajoutées à un tableau d'objets `attachments`.

Un objet `datamail` est créé avec les informations de l'e-mail à envoyer, y compris l'expéditeur, le destinataire, les pièces jointes, le sujet, le texte et le contenu HTML. Cet objet est ensuite envoyé à l'URL du service de messagerie via une requête POST.

Enfin, la fonction retourne la réponse de la requête POST effectuée vers le service de messagerie.

### Fonction sendEmailWithTemplateCustomer

La fonction `sendEmailWithTemplateCustomer` est une fonction asynchrone qui envoie un e-mail avec un modèle prédéfini spécifique pour un client donné. Elle prend les paramètres suivants :

-   `brand` : La marque du client.
-   `filter` : Un filtre à appliquer (informations spécifiques non fournies).

La fonction appelle la fonction `sendMailWithTemplate` en fournissant les paramètres nécessaires, y compris l'adresse e-mail de destination (`emailDest`), l'adresse e-mail de l'expéditeur (`emailFrom`), le nom du modèle de courrier électronique (`template`) et les données (`data`) qui incluent la marque (`brand`) et un tableau généré à partir du filtre (`filter`).

### Fonction sendEmailWithTemplate

La fonction `sendEmailWithTemplate` est une fonction asynchrone qui envoie un e-mail avec un modèle prédéfini pour un filtre donné. Elle prend les paramètres suivants :

-   `filter` : Un filtre à appliquer (informations spécifiques non fournies).

La fonction appelle la fonction `sendMailWithTemplate` en fournissant les paramètres nécessaires, y compris l'adresse e-mail de destination (`emailDest`), l'adresse e-mail de l'expéditeur (`emailFrom`), le nom du modèle de courrier électronique (`template`) et les données (`data`) qui incluent un tableau généré à partir du filtre (`filter`).

## Export des fonctions

Les fonctions `checkBetween`, `checkExists`, `checkValue`, `getFieldValue`, `getLocationFirstValue`, `getLocationSecondValue`, `compare`, `contains`, `isEmpty`, `filterResult`, `processResponse`, `processResults`, `isJson`, `isNumber`, `isString`, `isBoolean`, `isArray`, `sendMailWithTemplate`, `sendEmailWithTemplate` et `sendEmailWithTemplateCustomer` sont exportées pour être utilisées dans d'autres modules.

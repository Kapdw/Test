# Documentation des fonctions

## Fichier data.js

### Classe HttpApiV2

La classe `HttpApiV2` est importée à partir du module `nodelib` et est utilisée pour effectuer des requêtes HTTP. Aucune autre information n'est disponible sur cette classe dans le code fourni.

### Fonction getData

La fonction `getData` est exportée et permet de récupérer des données à partir d'une liste d'URLs spécifiées. Elle prend les paramètres suivants :

-   `urlCustomers` : L'URL de base des clients.
-   `jsonData` : Les données JSON contenant les informations de routage.

La fonction commence par appeler la fonction `path` pour obtenir les routes à partir des données JSON fournies. Ensuite, elle construit une liste d'URLs complètes en concaténant l'URL de base des clients avec chaque route.

La fonction crée un tableau de promesses en utilisant la méthode `http.get` pour chaque URL. Ensuite, elle utilise `Promise.all` pour attendre que toutes les requêtes soient résolues.

Une fois que toutes les requêtes sont terminées avec succès, les résultats sont stockés dans un tableau `results`. Pour chaque réponse, si les données des clients peuvent être extraites de la réponse, elles sont ajoutées au tableau `results`. Sinon, un objet d'erreur est ajouté au tableau.

Enfin, la fonction résout la promesse avec le tableau `results` contenant les données des clients récupérées.

### Fonction getDataForCompare

La fonction `getDataForCompare` est exportée et permet de récupérer des données spécifiques à des fins de comparaison à partir d'une liste d'URLs spécifiées. Elle prend les mêmes paramètres que la fonction `getData` : `urlCustomers` et `jsonData`.

La fonction suit un processus similaire à la fonction `getData`, mais avec une différence. Avant de construire la liste d'URLs complètes, la fonction effectue une vérification pour s'assurer que les données JSON contiennent une propriété `route` dans chaque objet de la liste `verif`. Si aucune route n'est trouvée, la promesse est résolue avec la valeur `undefined`.

Si des routes sont trouvées, la fonction continue de la même manière que la fonction `getData`. Elle construit une liste d'URLs complètes, effectue des requêtes pour chaque URL et stocke les résultats dans un tableau `results`. Ensuite, la promesse est résolue avec le tableau `results` contenant les données des clients récupérées.

### Fonction path

La fonction `path` est une fonction interne utilisée par les fonctions `getData` et `getDataForCompare`. Elle prend un objet JSON `jason` en entrée et retourne un tableau de données de routage.

La fonction parcourt les éléments de `way` dans `jason` et extrait les propriétés `fields`, `error`, `range`, `condition`, `route`, `role` et `location`. Si `fields` est une chaîne de caractères, elle est séparée en un tableau de champs. Si `fields` est un tableau, chaque élément est séparé en un tableau de champs distincts.

Enfin, la fonction retourne le tableau de résultats contenant les données de routage.

## Fichier files.js

### Module fs

Le module `fs` est importé pour gérer les opérations de fichiers. La fonction `loadFileAsJson` utilise `fs` pour charger un fichier JSON et le convertir en objet JavaScript.

### Fonction loadFileAsJson

La fonction `loadFileAsJson` est exportée et prend un paramètre `filename` qui spécifie le nom du fichier JSON à charger.

La fonction commence par afficher un message indiquant le chargement du fichier.

Ensuite, elle utilise `fs.readFileSync` pour lire le contenu du fichier de manière synchrone, c'est-à-dire en bloquant l'exécution jusqu'à ce que le fichier soit entièrement lu.

Le contenu brut du fichier est ensuite converti en objet JavaScript à l'aide de `JSON.parse`.

Si une erreur se produit pendant le processus de chargement ou de conversion, l'erreur est affichée dans la console et propagée (jetée) pour être gérée par l'appelant de la fonction.

Enfin, l'objet JavaScript résultant est retourné.

## Export des fonctions

Les fonctions `getData`, `getDataForCompare`, `path` et `loadFileAsJson` sont exportées pour être utilisées dans d'autres modules.

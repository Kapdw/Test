V1.0.0
Mailer_URL = http://localhost: + PORT

Docgen_URL = http://localhost: + PORT

EmailDest = email qui reçoit

DataJson = chemin absolue menant au fichier json

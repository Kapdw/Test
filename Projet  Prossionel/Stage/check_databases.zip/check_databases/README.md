# check_databases

Le projet check_databases a pour but de vérifier la base de données d'une marque afin de voir si les données sont des données valables/valides

# Pré-requis

Configurer le .env

# Installation

. `npm intall`

# Démarrage

. `nodemon src/server.js` ou `node src/server.js`

test

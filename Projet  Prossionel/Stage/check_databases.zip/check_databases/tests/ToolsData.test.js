const { HttpApiV2, logger } = require('nodelib');
const http = new HttpApiV2();

const ToolsData = require('../src/tools/data');
const mocha = require('mocha');
const sinon = require('sinon');

const chai = require('chai');
const res = require('./data/pointofinterest.json');

describe('ToolsData', function () {
    describe('ToolsData.path', () => {
        it('should return a array if all data exists and if fields is a array', () => {
            const jason = {
                toCheck: [
                    {
                        role: 'media MOB,DSK,VID',
                        api: 'customers',
                        route: '/pointsofinterest/medias/?category_code=MOB,DSK,VID',
                        fields: ['prices.1.budget', 'prices.2.budget'],
                        location: {
                            point_code: 'point_code',
                            category_code: 'category_code',
                        },
                        condition: 'between',
                        range: {
                            low: '100',
                            high: '2000',
                            expectedtype: 'number',
                        },
                        error: 'Invalid budget ',
                    },
                ],
            };
            const expectedResult = [
                {
                    fieldss: ['prices', '1', 'budget'],
                    error: 'Invalid budget ',
                    range: { low: '100', high: '2000', expectedtype: 'number' },
                    condition: 'between',
                    route: '/pointsofinterest/medias/?category_code=MOB,DSK,VID',
                    role: 'media MOB,DSK,VID',
                    location: { point_code: 'point_code', category_code: 'category_code' },
                },
                {
                    fieldss: ['prices', '2', 'budget'],
                    error: 'Invalid budget ',
                    range: { low: '100', high: '2000', expectedtype: 'number' },
                    condition: 'between',
                    route: '/pointsofinterest/medias/?category_code=MOB,DSK,VID',
                    role: 'media MOB,DSK,VID',
                    location: { point_code: 'point_code', category_code: 'category_code' },
                },
            ];
            const result = ToolsData.path(jason);

            chai.expect(result).to.be.eql(expectedResult);
            chai.expect(result).to.be.an('array');
        });
        it('should return a array if all data exists and if fields is a string', () => {
            const jason = {
                toCheck: [
                    {
                        role: 'media MOB,DSK,VID',
                        api: 'customers',
                        route: '/pointsofinterest/medias/?category_code=MOB,DSK,VID',
                        fields: 'prices.1.budget',
                        location: {
                            point_code: 'point_code',
                            category_code: 'category_code',
                        },
                        condition: 'between',
                        range: {
                            low: '100',
                            high: '2000',
                            expectedtype: 'number',
                        },
                        error: 'Invalid budget ',
                    },
                ],
            };
            const expectedResult = [
                {
                    fieldss: ['prices', '1', 'budget'],
                    error: 'Invalid budget ',
                    range: { low: '100', high: '2000', expectedtype: 'number' },
                    condition: 'between',
                    route: '/pointsofinterest/medias/?category_code=MOB,DSK,VID',
                    role: 'media MOB,DSK,VID',
                    location: { point_code: 'point_code', category_code: 'category_code' },
                },
            ];
            const result = ToolsData.path(jason);

            chai.expect(result).to.be.eql(expectedResult);
            chai.expect(result).to.be.an('array');
        });
    });
    describe('ToolsData.getData', () => {
        it('should return array of the data of the api', async () => {
            const urlCustomers = 'http://apiv2.adcleek.it/customers/ds';
            const httpGetStub = sinon.stub(HttpApiV2.prototype, 'get');
            const jsonData = {
                toCheck: [
                    {
                        role: 'media MOB,DSK,VID',
                        api: 'customers',
                        route: '/pointsofinterest/medias/?category_code=MOB,DSK,VID',
                        fields: 'prices.1.budget',
                        location: {
                            point_code: 'point_code',
                            category_code: 'category_code',
                        },
                        condition: 'between',
                        range: {
                            low: '100',
                            high: '2000',
                            expectedtype: 'number',
                        },
                        error: 'Invalid budget ',
                    },
                ],
            };
            const url = urlCustomers + jsonData.toCheck[0].route;
            httpGetStub.withArgs(url).resolves(res);
            const expectedResult = [
                [
                    {
                        timestamp: '2020-11-25T05:21:53.000Z',
                        status: 1,
                        point_code: '004674V',
                        media_code: 'FRADSK004674V',
                        country_code: 'FRA',
                        media_shortcode: 'DSK004674V',
                        category_code: 'DSK',
                        group_code: 'DSK',
                        agency_code: 'DSK',
                        geometry_hash: '6493ab6024cf68c12c7128f898643e20',
                        prices: {
                            1: {
                                budget: 420,
                                impressions: 105000,
                            },
                            2: {
                                budget: 448,
                                impressions: 112000,
                            },
                            3: {
                                budget: 476,
                                impressions: 119000,
                            },
                        },
                    },
                ],
            ];
            const result = await ToolsData.getData(urlCustomers, jsonData);
            chai.expect(result).to.be.eql(expectedResult);
            chai.expect(result).to.be.an('array');
        });
    });
});

const businessDataProcessing = require('../src/business/dataProcessing');

const mocha = require('mocha');
const sinon = require('sinon');
const chai = require('chai');

describe('businessDataProcessing', function () {
    describe('businessDataProcessing.processResponse', function () {
        it('should return a object if the condition exist', async () => {
            const response = [
                {
                    timestamp: '2020-11-25T05:21:54.000Z',
                    status: 1,
                    point_code: '058249P',
                    media_code: 'FRADSK058249P',
                    country_code: 'FRA',
                    media_shortcode: 'DSK058249P',
                    category_code: 'DSK',
                    group_code: 'DSK',
                    agency_code: 'DSK',
                    geometry_hash: '682bebd256b53875279718cd9071af3c',
                    prices: {
                        1: {
                            budget: 420,
                            impressions: 105000,
                        },
                        2: {
                            budget: 448,
                            impressions: 112000,
                        },
                        3: {
                            budget: 476,
                            impressions: 119000,
                        },
                    },
                    details: [Object],
                    pointofinterest: null,
                },
            ];
            const compare = [
                {
                    timestamp: '2020-11-25T05:21:54.000Z',
                    status: 1,
                    point_code: '058249P',
                    media_code: 'FRADSK058249P',
                    country_code: 'FRA',
                    media_shortcode: 'DSK058249P',
                    category_code: 'DSK',
                    group_code: 'DSK',
                    agency_code: 'DSK',
                    geometry_hash: '682bebd256b53875279718cd9071af3c',
                    prices: {
                        1: {
                            budget: 420,
                            impressions: 105000,
                        },
                        2: {
                            budget: 448,
                            impressions: 112000,
                        },
                        3: {
                            budget: 476,
                            impressions: 119000,
                        },
                    },
                    details: [Object],
                    pointofinterest: null,
                },
            ];
            const waydata = {
                role: 'media MOB,DSK,VID',
                api: 'customers',
                route: '/pointsofinterest/medias/?category_code=MOB,DSK,VID',
                fieldss: ['prices', '1', 'budget'],
                error: 'Invalid budget ',
                range: { low: '100', high: '2000', expectedtype: 'number' },
                condition: 'between',
                location: ['point_code', 'category_code'],
            };
            const expectedResult = {
                result: { error: 'Invalid data', value: 'undefined', type: 'undefined' },
                role: 'media MOB,DSK,VID',
            };
            const result = await businessDataProcessing.processResponse(response, waydata, compare);

            chai.expect(result).to.be.eql(expectedResult);
            chai.expect(result).to.be.an('object');
        });
        it("should return a object if the condition dinn't exists", async () => {
            const response = [
                {
                    timestamp: '2020-11-25T05:21:54.000Z',
                    status: 1,
                    point_code: '058249P',
                    media_code: 'FRADSK058249P',
                    country_code: 'FRA',
                    media_shortcode: 'DSK058249P',
                    category_code: 'DSK',
                    group_code: 'DSK',
                    agency_code: 'DSK',
                    geometry_hash: '682bebd256b53875279718cd9071af3c',
                    prices: {
                        1: {
                            budget: 420,
                            impressions: 105000,
                        },
                        2: {
                            budget: 448,
                            impressions: 112000,
                        },
                        3: {
                            budget: 476,
                            impressions: 119000,
                        },
                    },
                    details: [Object],
                    pointofinterest: null,
                },
            ];
            const waydata = {
                fieldss: ['prices', '1', 'budget'],
                error: 'Invalid budget ',
                range: { low: '100', high: '2000', expectedtype: 'number' },
                condition: 'rien',
                route: '/pointsofinterest/medias/?category_code=MOB,DSK,VID',
                role: 'media MOB,DSK,VID',
                location: ['point_code', 'category_code'],
            };
            const expectedResult = { error: `Invalid condition: rien` };
            const result = await businessDataProcessing.processResponse(response, waydata);
            chai.expect(result).to.be.eql(expectedResult);
            chai.expect(result).to.be.an('object');
        });
    });
    describe('businessDataProcessing.filterResult', () => {
        it('should return a array with the errors found', () => {
            const results = [
                {
                    result: [
                        {
                            point_code: '058220H',
                            category_code: 'VID',
                            role: 'media MOB,DSK,VID',
                            error: 'Invalid budget ',
                            value: '80',
                            type: 'Value is out of range, not between 100 and 2000',
                        },
                        {
                            point_code: '058277V',
                            category_code: 'VID',
                            role: 'media MOB,DSK,VID',
                            error: 'Invalid budget ',
                            value: '80',
                            type: 'Value is out of range, not between 100 and 2000',
                        },
                    ],
                    role: 'media MOB,DSK,VID',
                },
            ];
            const expectedResult = [
                {
                    point_code: '058220H',
                    category_code: 'VID',
                    role: 'media MOB,DSK,VID',
                    error: 'Invalid budget ',
                    value: '80',
                    type: 'Value is out of range, not between 100 and 2000',
                },
                {
                    point_code: '058277V',
                    category_code: 'VID',
                    role: 'media MOB,DSK,VID',
                    error: 'Invalid budget ',
                    value: '80',
                    type: 'Value is out of range, not between 100 and 2000',
                },
            ];
            const result = businessDataProcessing.filterResult(results);
            chai.expect(result).to.be.eql(expectedResult);
            chai.expect(result).to.be.an('array');
        });
    });
    describe('businessDataProcessing.processResults', () => {
        it('should be a array if the compare is undefined and they are a value for fieldValue ', async () => {
            const responses = [
                {
                    data: [
                        {
                            timestamp: '2020-11-25T05:21:53.000Z',
                            status: 1,
                            point_code: '004674V',
                            media_code: 'FRADSK004674V',
                            country_code: 'FRA',
                            media_shortcode: 'DSK004674V',
                            category_code: 'DSK',
                            group_code: 'DSK',
                            agency_code: 'DSK',
                            geometry_hash: '6493ab6024cf68c12c7128f898643e20',
                            prices: {
                                1: {
                                    budget: 420,
                                    impressions: 105000,
                                },
                                2: {
                                    budget: 448,
                                    impressions: 112000,
                                },
                                3: {
                                    budget: 476,
                                    impressions: 119000,
                                },
                            },
                            details: [Object],
                            pointofinterest: [Object],
                        },
                    ],
                },
            ];
            const waydata = [
                {
                    fieldss: ['prices', '1', 'impressions'],
                    error: 'Invalid Impression',
                    range: { low: '5600', high: '175000', expectedtype: 'number' },
                    condition: 'between',
                    route: '/pointsofinterest/medias/?category_code=MOB,DSK',
                    role: 'Impressions in medias',
                    location: ['point_code', 'category_code'],
                },
            ];
            const compare = undefined;
            const expectedResult = [{ result: { success: true }, role: 'Impressions in medias' }];
            const result = await businessDataProcessing.processResults(responses, waydata, compare);
            chai.expect(result).to.be.eql(expectedResult);
            chai.expect(result).to.be.an('Array');
        });
        it('should be a array if the compare is not undefined and they are a value for fieldValue ', async () => {
            const responses = [
                {
                    data: [
                        {
                            timestamp: '2020-11-25T05:21:53.000Z',
                            status: 1,
                            point_code: '004674V',
                            media_code: 'FRADSK004674V',
                            country_code: 'FRA',
                            media_shortcode: 'DSK004674V',
                            category_code: 'DSK',
                            group_code: 'DSK',
                            agency_code: 'DSK',
                            geometry_hash: '6493ab6024cf68c12c7128f898643e20',
                            prices: {
                                1: {
                                    budget: 420,
                                    impressions: 105000,
                                },
                                2: {
                                    budget: 448,
                                    impressions: 112000,
                                },
                                3: {
                                    budget: 476,
                                    impressions: 119000,
                                },
                            },
                            details: [Object],
                            pointofinterest: [Object],
                        },
                    ],
                },
            ];
            const waydata = [
                {
                    fieldss: ['prices', '1', 'impressions'],
                    error: 'Invalid Impression',
                    range: { low: '5600', high: '175000', expectedtype: 'number' },
                    condition: 'between',
                    route: '/pointsofinterest/medias/?category_code=MOB,DSK',
                    role: 'Impressions in medias',
                    location: ['point_code', 'category_code'],
                },
            ];
            const compare = [
                {
                    data: [
                        {
                            code: 'UZ5JW',
                            point_code: '004674V',
                            group_code: 'DS_SUD_EST',
                            created_at: '2020-11-25T07:22:18.000Z',
                            updated_at: '2020-11-25T07:22:18.000Z',
                        },
                    ],
                },
            ];
            const expectedResult = [[{ result: { success: true }, role: 'Impressions in medias' }]];

            const result = await businessDataProcessing.processResults(responses, waydata, compare);
            chai.expect(result).to.be.eql(expectedResult);
        });
        it('should be a array if they are not a valid value for fieldValue and compare is undefined', async () => {
            const responses = [
                {
                    data: [
                        {
                            timestamp: '2020-11-25T05:21:53.000Z',
                            status: 1,
                            point_code: '004674V',
                            media_code: 'FRADSK004674V',
                            country_code: 'FRA',
                            media_shortcode: 'DSK004674V',
                            category_code: 'DSK',
                            group_code: 'DSK',
                            agency_code: 'DSK',
                            prices: {
                                1: {},
                                2: {},
                                3: {},
                            },
                            geometry_hash: '6493ab6024cf68c12c7128f898643e20',
                            details: [Object],
                            pointofinterest: [Object],
                        },
                    ],
                },
            ];
            const waydata = [
                {
                    fieldss: ['prices', '1', 'impressions'],
                    error: 'Invalid Impression',
                    range: { low: '5600', high: '175000', expectedtype: 'number' },
                    condition: 'between',
                    route: '/pointsofinterest/medias/?category_code=MOB,DSK',
                    role: 'Impressions in medias',
                    location: ['point_code', 'category_code'],
                },
            ];
            const compare = undefined;
            const expectedResult = [
                {
                    result: [
                        {
                            error: 'Invalid Impression',
                            value: '[object Object]',
                            type: "Field doesn't exist",
                            point_code: '004674V',
                            category_code: 'DSK',
                        },
                    ],
                    role: 'Impressions in medias',
                },
            ];
            const result = await businessDataProcessing.processResults(responses, waydata, compare);
            chai.expect(result).to.be.eql(expectedResult);
            chai.expect(result).to.be.an('Array');
        });
        it('should be a array if they are not a valid value for fieldValue and compare is not undefined', async () => {
            const responses = [
                {
                    data: [
                        {
                            status: 1,
                            point_code: '004674V',
                            media_code: 'FRADSK004674V',
                            country_code: 'FRA',
                            category_code: 'DSK',
                            group_code: 'DSK',
                            agency_code: 'DSK',
                            prices: {
                                1: {},
                                2: {},
                                3: {},
                            },
                        },
                    ],
                },
            ];
            const waydata = [
                {
                    fieldss: ['prices', '1', 'impressions'],
                    error: 'Invalid Impression',
                    range: { low: '5600', high: '175000', expectedtype: 'number' },
                    condition: 'between',
                    route: '/pointsofinterest/medias/?category_code=MOB,DSK',
                    role: 'Impressions in medias',
                    location: ['point_code', 'category_code'],
                },
            ];
            const compare = [
                {
                    data: [
                        {
                            code: 'UZ5JW',
                            point_code: '004674V',
                            group_code: 'DS_SUD_EST',
                            created_at: '2020-11-25T07:22:18.000Z',
                            updated_at: '2020-11-25T07:22:18.000Z',
                        },
                    ],
                },
            ];
            const expectedResult = [
                [
                    {
                        result: [
                            {
                                category_code: 'DSK',
                                error: 'Invalid Impression',
                                point_code: '004674V',
                                type: "Field doesn't exist",
                                value: '[object Object]',
                            },
                        ],
                        role: 'Impressions in medias',
                    },
                ],
            ];
            const result = await businessDataProcessing.processResults(responses, waydata, compare);
            chai.expect(result).to.be.eql(expectedResult);
            chai.expect(result).to.be.an('array');
        });
    });
});

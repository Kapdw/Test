const businessCompare = require('../src/business/compare');

const mocha = require('mocha');
const sinon = require('sinon');
const chai = require('chai');

describe('businessCompare', () => {
    describe('businessCompare.compare', () => {
        it('should return a object if the value of the first route are in the second route', () => {
            const customer = [
                {
                    timestamp: '2020-11-25T05:21:53.000Z',
                    status: 1,
                    point_code: '004674V',
                    media_code: 'FRADSK004674V',
                    country_code: 'FRA',
                    media_shortcode: 'DSK004674V',
                    category_code: 'DSK',
                    group_code: 'DSK',
                    agency_code: 'DSK',
                    geometry_hash: '6493ab6024cf68c12c7128f898643e20',
                    prices: {
                        1: { budget: 420, impressions: 105000 },
                        2: { budget: 448, impressions: 112000 },
                        3: { budget: 476, impressions: 119000 },
                    },
                },
            ];
            const fields = ['point_code'];
            const range = { api: 'customer', route: '/pointofinterest/info' };
            const error = 'Invalide point_code';
            const location = ['point_code'];
            const compare = [
                {
                    code: 'PGWWJ',
                    point_code: '004674V',
                    group_code: 'CHOPARD',
                    created_at: '2020-11-25T07:22:18.000Z',
                    updated_at: '2020-11-25T07:22:18.000Z',
                },
            ];
            const expectedResult = { success: true };
            const result = businessCompare.compare(customer, fields, range, error, location, compare);

            chai.expect(result).to.be.eql(expectedResult);
            chai.expect(result).to.be.an('object');
        });
        it('should return a array if the value of the first route are not in the second route', () => {
            const customer = [
                {
                    timestamp: '2020-11-25T05:21:53.000Z',
                    status: 1,
                    point_code: 'RYAN',
                    media_code: 'FRADSK004674V',
                    country_code: 'FRA',
                    media_shortcode: 'DSK004674V',
                    category_code: 'DSK',
                    group_code: 'DSK',
                    agency_code: 'DSK',
                    geometry_hash: '6493ab6024cf68c12c7128f898643e20',
                    prices: {
                        1: { budget: 420, impressions: 105000 },
                        2: { budget: 448, impressions: 112000 },
                        3: { budget: 476, impressions: 119000 },
                    },
                },
            ];
            const fields = ['point_code'];
            const range = { api: 'customer', route: '/pointofinterest/info' };
            const error = 'Invalide point_code';
            const location = ['point_code'];
            const compare = [
                {
                    code: 'PGWWJ',
                    point_code: '004674V',
                    group_code: 'CHOPARD',
                    created_at: '2020-11-25T07:22:18.000Z',
                    updated_at: '2020-11-25T07:22:18.000Z',
                },
            ];
            const expectedResult = [{ error: `${error}`, value: `RYAN`, type: `This value don't exist in ${range.route}`, point_code: 'RYAN', category_code: '' }];
            const result = businessCompare.compare(customer, fields, range, error, location, compare);

            chai.expect(result).to.be.eql(expectedResult);
            chai.expect(result).to.be.an('array');
        });
        it('should return a array if customers and compare are empty ', () => {
            const customer = [
                {
                    timestamp: '2020-11-25T05:21:53.000Z',
                    status: 1,
                    media_code: 'FRADSK004674V',
                    country_code: 'FRA',
                    media_shortcode: 'DSK004674V',
                    category_code: 'DSK',
                    group_code: 'DSK',
                    agency_code: 'DSK',
                    geometry_hash: '6493ab6024cf68c12c7128f898643e20',
                    prices: {
                        1: { budget: 420, impressions: 105000 },
                        2: { budget: 448, impressions: 112000 },
                        3: { budget: null, impressions: null },
                    },
                },
            ];
            const fields = ['prices', '3', 'impressions'];
            const range = { low: '100', high: '119000', expectedtype: 'number' };
            const error = 'Invalid impression';
            const location = ['point_code', 'category_code'];
            const compare = [];
            const expectedResult = {
                error: `Invalid data`,
            };
            const result = businessCompare.compare(customer, fields, range, error, location, compare);
            chai.expect(result).to.be.eql(expectedResult);
            chai.expect(result).to.be.an('object');
        });
        it('should return a array if there is no value for point_code in the first route', () => {
            const customer = [
                {
                    timestamp: '2020-11-25T05:21:53.000Z',
                    status: 1,
                    media_code: 'FRADSK004674V',
                    country_code: 'FRA',
                    media_shortcode: 'DSK004674V',
                    category_code: 'DSK',
                    code: 'PGWWJ',
                    group_code: 'DSK',
                    agency_code: 'DSK',
                    geometry_hash: '6493ab6024cf68c12c7128f898643e20',
                    prices: {
                        1: { budget: 420, impressions: 105000 },
                        2: { budget: 448, impressions: 112000 },
                        3: { budget: 476, impressions: 119000 },
                    },
                },
            ];
            const fields = ['code'];
            const range = { api: 'customer', route: '/pointofinterest/info' };
            const error = 'Invalid budget';
            const location = ['point_code', 'category_code'];

            const compare = [
                {
                    code: 'PGWWJ',
                    category_code: 'DSK',
                    point_code: '004674V',
                    group_code: 'CHOPARD',
                    created_at: '2020-11-25T07:22:18.000Z',
                    updated_at: '2020-11-25T07:22:18.000Z',
                },
            ];

            const expectedResult = [{ error: `${error}`, value: 'unknown', type: `Field doesn't exist` }];
            const result = businessCompare.compare(customer, fields, range, error, location, compare);
            chai.expect(result).to.be.eql(expectedResult);
            chai.expect(result).to.be.an('array');
        });
        it('should return a array if there is no value for location[1]', () => {
            const customer = [
                {
                    timestamp: '2020-11-25T05:21:53.000Z',
                    status: 1,
                    point_code: '004674V',
                    media_code: 'FRADSK004674V',
                    media_shortcode: 'DSK004674V',
                    group_code: 'DSK',
                    agency_code: 'DSK',
                    geometry_hash: '6493ab6024cf68c12c7128f898643e20',
                    prices: {
                        1: { budget: 420, impressions: 105000 },
                        2: { budget: 448, impressions: 112000 },
                        3: { budget: 476, impressions: 119000 },
                    },
                },
            ];
            const fields = ['point_code'];
            const range = { expectedValue: 1, expectedtype: 'number' };
            const error = 'Invalid Value';
            const location = ['point_code', 'category_code'];

            const compare = [
                {
                    code: 'PGWWJ',
                    category_code: 'DSK',
                    point_code: '004674V',
                    group_code: 'CHOPARD',
                    created_at: '2020-11-25T07:22:18.000Z',
                    updated_at: '2020-11-25T07:22:18.000Z',
                },
            ];

            const expectedResult = [{ error: `${error}`, value: 'unknown', type: `Field doesn't exist` }];
            const result = businessCompare.compare(customer, fields, range, error, location, compare);
            chai.expect(result).to.be.eql(expectedResult);
            chai.expect(result).to.be.an('array');
        });
        it('should return a array if the fieldValue does not exist', () => {
            const customer = [
                {
                    timestamp: '2020-11-25T05:21:53.000Z',
                    point_code: '004674V',
                    media_code: 'FRADSK004674V',
                    media_shortcode: 'DSK004674V',
                    category_code: 'DSK',
                    agency_code: 'DSK',
                    geometry_hash: '6493ab6024cf68c12c7128f898643e20',
                    prices: {
                        1: { budget: 420, impressions: 105000 },
                        2: { budget: 448, impressions: 112000 },
                        3: { budget: 476, impressions: 119000 },
                    },
                },
            ];
            const fields = ['group_code'];
            const range = { api: 'customer', route: '/pointofinterest/info' };
            const error = 'Invalide point_code';
            const location = ['point_code', 'category_code'];

            const compare = [
                {
                    code: 'PGWWJ',
                    category_code: 'DSK',
                    point_code: '004674V',
                    group_code: 'CHOPARD',
                    created_at: '2020-11-25T07:22:18.000Z',
                    updated_at: '2020-11-25T07:22:18.000Z',
                },
            ];

            const expectedResult = [
                {
                    error: 'Invalide point_code',
                    value: '[object Object]',
                    type: "Field doesn't exist",
                    point_code: '004674V',
                    category_code: 'DSK',
                },
                {
                    error: 'Invalide point_code',
                    value: '[object Object]',
                    type: "This value don't exist in /pointofinterest/info",
                    point_code: '004674V',
                    category_code: 'DSK',
                },
            ];
            const result = businessCompare.compare(customer, fields, range, error, location, compare);
            chai.expect(result).to.be.eql(expectedResult);
            chai.expect(result).to.be.an('array');
        });
    });
});

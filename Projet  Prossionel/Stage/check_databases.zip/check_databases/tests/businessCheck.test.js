const BusinessCheck = require('../src/business/check');
const mocha = require('mocha');
const sinon = require('sinon');

const chai = require('chai');

describe('BusinessCheck', function () {
    describe('BusinessCheck.checkBetween', function () {
        it('should return a object if the value is between low and high ', function () {
            const customer = [
                {
                    timestamp: '2020-11-25T05:21:53.000Z',
                    status: 1,
                    point_code: '004674V',
                    media_code: 'FRADSK004674V',
                    country_code: 'FRA',
                    media_shortcode: 'DSK004674V',
                    category_code: 'DSK',
                    group_code: 'DSK',
                    agency_code: 'DSK',
                    geometry_hash: '6493ab6024cf68c12c7128f898643e20',
                    prices: {
                        1: { budget: 420, impressions: 105000 },
                        2: { budget: 448, impressions: 112000 },
                        3: { budget: 476, impressions: 119000 },
                    },
                },
            ];
            const fields = ['prices', '2', 'budget'];
            const range = { low: '100', high: '2000', expectedtype: 'number' };
            const error = 'Invalid budget';
            const location = ['point_code', 'category_code'];
            const expectedResult = { success: true };

            const result = BusinessCheck.checkBetween(customer, fields, range, error, location);
            chai.expect(result).to.be.eql(expectedResult);
            chai.expect(result).to.be.an('object');
        });
        it('should return a array if the value is not between low and high', () => {
            const customer = [
                {
                    timestamp: '2020-11-25T05:21:53.000Z',
                    status: 1,
                    point_code: '004674V',
                    media_code: 'FRADSK004674V',
                    country_code: 'FRA',
                    media_shortcode: 'DSK004674V',
                    category_code: 'DSK',
                    group_code: 'DSK',
                    agency_code: 'DSK',
                    geometry_hash: '6493ab6024cf68c12c7128f898643e20',
                    prices: {
                        1: { budget: 80, impressions: 105000 },
                        2: { budget: 448, impressions: 112000 },
                        3: { budget: 476, impressions: 119000 },
                    },
                },
            ];
            const fields = ['prices', '1', 'budget'];
            const range = { low: '100', high: '2000', expectedtype: 'number' };
            const error = 'Invalid budget';
            const location = ['point_code', 'category_code'];
            const expectedResult = [{ error: `${error}`, value: '80', type: `Value is out of range, not between ${range.low} and ${range.high}`, point_code: '004674V', category_code: 'DSK' }];

            const result = BusinessCheck.checkBetween(customer, fields, range, error, location);
            chai.expect(result).to.be.eql(expectedResult);
            chai.expect(result).to.be.an('array');
        });
        it('should return a array if the type of the value is not a number ', () => {
            const customer = [
                {
                    timestamp: '2020-11-25T05:21:53.000Z',
                    status: 1,
                    point_code: '004674V',
                    media_code: 'FRADSK004674V',
                    country_code: 'FRA',
                    media_shortcode: 'DSK004674V',
                    category_code: 'DSK',
                    group_code: 'DSK',
                    agency_code: 'DSK',
                    geometry_hash: '6493ab6024cf68c12c7128f898643e20',
                    prices: {
                        1: { budget: 420, impressions: 105000 },
                        2: { budget: 448, impressions: 112000 },
                        3: { budget: "c'est pas un nombre", impressions: 119000 },
                    },
                },
            ];
            const fields = ['prices', '3', 'budget'];
            const range = { low: '100', high: '2000', expectedtype: 'number' };
            const error = 'Invalid budget';
            const location = ['point_code', 'category_code'];
            const expectedResult = [
                {
                    error: `${error}`,
                    value: "c'est pas un nombre",
                    type: `The expected value type is ${range.expectedtype} when it is found that the type is string`,
                    point_code: '004674V',
                    category_code: 'DSK',
                },
            ];
            const result = BusinessCheck.checkBetween(customer, fields, range, error, location);

            chai.expect(result).to.be.eql(expectedResult);
            chai.expect(result).to.be.an('array');
        });
        it('should return a array if value is empty ', () => {
            const customer = [
                {
                    timestamp: '2020-11-25T05:21:53.000Z',
                    status: 1,
                    media_code: 'FRADSK004674V',
                    country_code: 'FRA',
                    media_shortcode: 'DSK004674V',
                    category_code: 'DSK',
                    group_code: 'DSK',
                    agency_code: 'DSK',
                    geometry_hash: '6493ab6024cf68c12c7128f898643e20',
                    prices: {
                        1: { budget: 420, impressions: 105000 },
                        2: { budget: 448, impressions: 112000 },
                        3: { budget: null, impressions: null },
                    },
                },
            ];
            const fields = ['prices', '3', 'impressions'];
            const range = { low: '100', high: '119000', expectedtype: 'number' };
            const error = 'Invalid impression';
            const location = ['point_code', 'category_code'];
            const expectedResult = [
                {
                    error: `${error}`,
                    value: 'unknown',
                    type: "Field doesn't exist",
                },
            ];
            const result = BusinessCheck.checkBetween(customer, fields, range, error, location);
            chai.expect(result).to.be.eql(expectedResult);
            chai.expect(result).to.be.an('array');
        });
        it('should return a object if the customer is empty', () => {
            const customers = { data: [{}] };
            const fields = ['prices', '3', 'budget'];
            const range = { low: '100', high: '2000', expectedtype: 'number' };
            const error = 'Invalid budget';
            const location = { point_code: 'point_code', category_code: 'category_code' };
            const expectedResult = { error: 'Invalid data', value: '[object Object]', type: 'object' };

            const result = BusinessCheck.checkBetween(customers, fields, range, error, location);

            chai.expect(result).to.be.eql(expectedResult);
            chai.expect(result).to.be.an('object');
        });
        it('should return a array if there is no value for point_code', () => {
            const customer = [
                {
                    timestamp: '2020-11-25T05:21:53.000Z',
                    status: 1,
                    media_code: 'FRADSK004674V',
                    country_code: 'FRA',
                    media_shortcode: 'DSK004674V',
                    category_code: 'DSK',
                    group_code: 'DSK',
                    agency_code: 'DSK',
                    geometry_hash: '6493ab6024cf68c12c7128f898643e20',
                    prices: {
                        1: { budget: 420, impressions: 105000 },
                        2: { budget: 448, impressions: 112000 },
                        3: { budget: 476, impressions: 119000 },
                    },
                },
            ];
            const fields = ['status'];
            const range = { expectedValue: 1, expectedtype: 'number' };
            const error = 'Invalid Value';
            const location = ['point_code', 'category_code'];

            const expectedResult = [{ error: `${error}`, value: 'unknown', type: `Field doesn't exist` }];
            const result = BusinessCheck.checkBetween(customer, fields, range, error, location);
            chai.expect(result).to.be.eql(expectedResult);
            chai.expect(result).to.be.an('array');
        });
        it('should return a array if there is no value for category_code', () => {
            const customer = [
                {
                    timestamp: '2020-11-25T05:21:53.000Z',
                    status: 1,
                    point_code: '004674V',
                    media_code: 'FRADSK004674V',
                    media_shortcode: 'DSK004674V',
                    group_code: 'DSK',
                    agency_code: 'DSK',
                    geometry_hash: '6493ab6024cf68c12c7128f898643e20',
                    prices: {
                        1: { budget: 420, impressions: 105000 },
                        2: { budget: 448, impressions: 112000 },
                        3: { budget: 476, impressions: 119000 },
                    },
                },
            ];
            const fields = ['status'];
            const range = { expectedValue: 1, expectedtype: 'number' };
            const error = 'Invalid Value';
            const location = ['point_code', 'category_code'];

            const expectedResult = [{ error: `${error}`, value: 'unknown', type: `Field doesn't exist` }];
            const result = BusinessCheck.checkBetween(customer, fields, range, error, location);
            chai.expect(result).to.be.eql(expectedResult);
            chai.expect(result).to.be.an('array');
        });
        it('should return a array if the fieldValue does not exist', () => {
            const customer = [
                {
                    timestamp: '2020-11-25T05:21:53.000Z',
                    point_code: '004674V',
                    media_code: 'FRADSK004674V',
                    media_shortcode: 'DSK004674V',
                    group_code: 'DSK',
                    category_code: 'DSK',
                    agency_code: 'DSK',
                    geometry_hash: '6493ab6024cf68c12c7128f898643e20',
                    prices: {
                        1: { budget: 420, impressions: 105000 },
                        2: { budget: 448, impressions: 112000 },
                        3: { budget: 476, impressions: 119000 },
                    },
                },
            ];
            const fields = ['status'];
            const range = { expectedValue: 1, expectedtype: 'number' };
            const error = 'Invalid Value';
            const location = ['point_code', 'category_code'];

            const expectedResult = [{ error: `${error}`, value: '[object Object]', type: `Field doesn't exist`, point_code: '004674V', category_code: 'DSK' }];
            const result = BusinessCheck.checkBetween(customer, fields, range, error, location);
            chai.expect(result).to.be.eql(expectedResult);
            chai.expect(result).to.be.an('array');
        });
    });
    describe('BusinessCheck.checkExists', function () {
        it('should return a object if the value is not empty  ', function () {
            const customer = [
                {
                    timestamp: '2020-11-25T05:21:53.000Z',
                    status: 1,
                    point_code: '004674V',
                    media_code: 'FRADSK004674V',
                    country_code: 'FRA',
                    media_shortcode: 'DSK004674V',
                    category_code: 'DSK',
                    group_code: 'DSK',
                    agency_code: 'DSK',
                    geometry_hash: '6493ab6024cf68c12c7128f898643e20',
                    prices: {
                        1: { budget: 420, impressions: 105000 },
                        2: { budget: 448, impressions: 112000 },
                        3: { budget: 476, impressions: 119000 },
                    },
                },
            ];
            const fields = ['prices', '1', 'impressions'];
            const range = { expectedtype: 'number' };
            const error = 'Invalid budget';
            const location = ['point_code', 'category_code'];
            const expectedResult = { success: true };

            const result = BusinessCheck.checkExists(customer, fields, range, error, location);
            chai.expect(result).to.be.eql(expectedResult);
            chai.expect(result).to.be.an('object');
        });
        it('should return a array if value is empty ', () => {
            const customer = [
                {
                    timestamp: '2020-11-25T05:21:53.000Z',
                    status: 1,
                    point_code: '004674V',
                    media_code: 'FRADSK004674V',
                    country_code: 'FRA',
                    media_shortcode: 'DSK004674V',
                    category_code: 'DSK',
                    group_code: 'DSK',
                    agency_code: 'DSK',
                    geometry_hash: '6493ab6024cf68c12c7128f898643e20',
                    prices: {
                        1: { budget: 420, impressions: 105000 },
                        2: { budget: 448, impressions: 112000 },
                        3: { budget: 476, impressions: null },
                    },
                },
            ];
            const fields = ['prices', '3', 'impressions'];
            const range = { expectedtype: 'number' };
            const error = 'Invalid impression';
            const location = ['point_code', 'category_code'];
            const expectedResult = [
                {
                    error: `${error}`,
                    value: 'null',
                    type: `Value do not exist type: object`,
                    point_code: '004674V',
                    category_code: 'DSK',
                },
            ];
            const result = BusinessCheck.checkExists(customer, fields, range, error, location);

            chai.expect(result).to.be.eql(expectedResult);
            chai.expect(result).to.be.an('array');
        });
        it('should return a object if the customer is empty', () => {
            const customers = { data: [{}] };
            const fields = ['prices', '3', 'budget'];
            const range = { low: '100', high: '2000', expectedtype: 'number' };
            const error = 'Invalid budget';
            const location = ['point_code', 'category_code'];
            const expectedResult = {
                error: `Invalid data`,
                value: '[object Object]',
                type: 'object',
            };

            const result = BusinessCheck.checkExists(customers, fields, range, error, location);

            chai.expect(result).to.be.eql(expectedResult);
            chai.expect(result).to.be.an('object');
        });
        it('should return a array if there is no value for point_code', () => {
            const customer = [
                {
                    timestamp: '2020-11-25T05:21:53.000Z',
                    status: 1,
                    media_code: 'FRADSK004674V',
                    country_code: 'FRA',
                    media_shortcode: 'DSK004674V',
                    category_code: 'DSK',
                    group_code: 'DSK',
                    agency_code: 'DSK',
                    geometry_hash: '6493ab6024cf68c12c7128f898643e20',
                    prices: {
                        1: { budget: 420, impressions: 105000 },
                        2: { budget: 448, impressions: 112000 },
                        3: { budget: 476, impressions: 119000 },
                    },
                },
            ];
            const fields = ['status'];
            const range = { expectedValue: 1, expectedtype: 'number' };
            const error = 'Invalid Value';
            const location = ['point_code', 'category_code'];

            const expectedResult = [{ error: `${error}`, value: 'unknown', type: `Field doesn't exist` }];
            const result = BusinessCheck.checkExists(customer, fields, range, error, location);
            chai.expect(result).to.be.eql(expectedResult);
            chai.expect(result).to.be.an('array');
        });
        it('should return a array if there is no value for category_code', () => {
            const customer = [
                {
                    timestamp: '2020-11-25T05:21:53.000Z',
                    status: 1,
                    point_code: '004674V',
                    media_code: 'FRADSK004674V',
                    media_shortcode: 'DSK004674V',
                    group_code: 'DSK',
                    agency_code: 'DSK',
                    geometry_hash: '6493ab6024cf68c12c7128f898643e20',
                    prices: {
                        1: { budget: 420, impressions: 105000 },
                        2: { budget: 448, impressions: 112000 },
                        3: { budget: 476, impressions: 119000 },
                    },
                },
            ];
            const fields = ['status'];
            const range = { expectedValue: 1, expectedtype: 'number' };
            const error = 'Invalid Value';
            const location = ['point_code', 'category_code'];

            const expectedResult = [{ error: `${error}`, value: 'unknown', type: `Field doesn't exist` }];
            const result = BusinessCheck.checkExists(customer, fields, range, error, location);
            chai.expect(result).to.be.eql(expectedResult);
            chai.expect(result).to.be.an('array');
        });
        it('should return a array if the fieldValue does not exist', () => {
            const customer = [
                {
                    timestamp: '2020-11-25T05:21:53.000Z',
                    point_code: '004674V',
                    media_code: 'FRADSK004674V',
                    media_shortcode: 'DSK004674V',
                    group_code: 'DSK',
                    category_code: 'DSK',
                    agency_code: 'DSK',
                    geometry_hash: '6493ab6024cf68c12c7128f898643e20',
                    prices: {
                        1: { budget: 420, impressions: 105000 },
                        2: { budget: 448, impressions: 112000 },
                        3: { budget: 476, impressions: 119000 },
                    },
                },
            ];
            const fields = ['status'];
            const range = { expectedValue: 1, expectedtype: 'number' };
            const error = 'Invalid Value';
            const location = ['point_code', 'category_code'];

            const expectedResult = [{ error: `${error}`, value: '[object Object]', type: `Field doesn't exist`, point_code: '004674V', category_code: 'DSK' }];
            const result = BusinessCheck.checkExists(customer, fields, range, error, location);
            chai.expect(result).to.be.eql(expectedResult);
            chai.expect(result).to.be.an('array');
        });
    });
    describe('BusinessCheck.checkValue', () => {
        it('should return a object if the value is equal to expectedValue ', () => {
            const quotation = [
                {
                    timestamp: '2021-10-21T11:25:04.000Z',
                    directory_uid: 'a8216563d40f7e22b615de80f37a101a',
                    type: ' ',
                    reference: '20190301019FF4F10EB8',
                    point_code: '004674V',
                    crea_code: ' ',
                    value: 2,
                    status: 1,
                    creation_date: '2019-03-01T10:59:36.000Z',
                    deadline: '2019-12-03T23:59:59.000Z',
                    campaign_start_date: '2019-03-01T10:55:48.000Z',
                },
            ];
            const fields = ['value'];
            const range = { exactValue: [0, 1, 2, 6], expectedtype: 'number' };
            const error = 'Invalid';
            const location = ['point_code', 'reference'];

            const expectedResult = { success: true };

            const result = BusinessCheck.checkValue(quotation, fields, range, error, location);

            chai.expect(result).to.be.eql(expectedResult);
            chai.expect(result).to.be.an('object');
        });
        it("should return a array if the value don't match expectedValue ", () => {
            const data = [
                {
                    timestamp: '2021-10-21T11:25:04.000Z',
                    directory_uid: 'a8216563d40f7e22b615de80f37a101a',
                    type: ' ',
                    reference: '20190301019FF4F10EB8',
                    point_code: '004674V',
                    crea_code: ' ',
                    status: 1,
                    creation_date: '2019-03-01T10:59:36.000Z',
                    deadline: '2019-12-03T23:59:59.000Z',
                    campaign_start_date: '2019-03-01T10:55:48.000Z',
                },
                {
                    timestamp: '2021-10-21T11:25:04.000Z',
                    directory_uid: '05ba2359eccacb51b7c33579b1bd9f33',
                    type: 'IO',
                    reference: '20210827008454AE26B6',
                    point_code: '004676H',
                    crea_code: 'ZS6NT',
                    status: 2,
                    creation_date: '2021-08-27T11:47:08.000Z',
                    deadline: '2021-08-27T23:59:59.000Z',
                    campaign_start_date: '2021-08-31T00:00:00.000Z',
                },
            ];
            const fields = ['status'];
            const range = { exactValue: 1, expectedtype: 'number' };
            const error = 'Invalid';
            const location = ['point_code', 'reference'];

            const expectedResult = [
                {
                    error: `${error}`,
                    value: '2',
                    type: `Value do not match and/or the type didn't match, type expected: ${range.expectedtype}, type obtened: number`,
                    point_code: `004676H`,
                    category_code: `20210827008454AE26B6`,
                },
            ];
            const result = BusinessCheck.checkValue(data, fields, range, error, location);
            chai.expect(result).to.be.eql(expectedResult);
            chai.expect(result).to.be.an('array');
        });
        it("should return a array if the value don't match the value expected and if the typeof the value don't match the type of expectedtype", () => {
            const quotation = [
                {
                    timestamp: '2021-10-21T11:25:04.000Z',
                    directory_uid: 'a8216563d40f7e22b615de80f37a101a',
                    type: ' ',
                    reference: '20190301019FF4F10EB8',
                    point_code: '004674V',
                    crea_code: ' ',
                    status: 1,
                    creation_date: '2019-03-01T10:59:36.000Z',
                    deadline: '2019-12-03T23:59:59.000Z',
                    campaign_start_date: '2019-03-01T10:55:48.000Z',
                },
                {
                    timestamp: '2021-10-21T11:25:04.000Z',
                    directory_uid: 'a8216563d40f7e22b615de80f37a101a',
                    type: ' ',
                    reference: '20190301019FF4F10EB8',
                    point_code: '004674V',
                    crea_code: ' ',
                    status: '0',
                    creation_date: '2019-03-01T10:59:36.000Z',
                    deadline: '2019-12-03T23:59:59.000Z',
                    campaign_start_date: '2019-03-01T10:55:48.000Z',
                },
            ];
            const fields = ['status'];
            const range = { exactValue: [1, '1'], expectedtype: 'string' };
            const error = 'Invalid';
            const location = ['point_code', 'reference'];

            const expectedResult = [
                {
                    error: 'Invalid',
                    value: '1',
                    type: `Value do not match and/or the type didn't match, type expected: ${range.expectedtype}, type obtened: number`,
                    point_code: '004674V',
                    category_code: '20190301019FF4F10EB8',
                },
                {
                    error: `${error}`,
                    value: '0',
                    type: `Value do not match and/or the type didn't match, type expected: ${range.expectedtype}, type obtened: string`,
                    point_code: `004674V`,
                    category_code: `20190301019FF4F10EB8`,
                },
            ];
            const result = BusinessCheck.checkValue(quotation, fields, range, error, location);
            chai.expect(result).to.be.eql(expectedResult);
            chai.expect(result).to.be.an('array');
        });
        it('should return a object if the customer is empty', () => {
            const customers = { data: [{}] };
            const fields = ['prices', '3', 'budget'];
            const range = { low: '100', high: '2000', expectedtype: 'number' };
            const error = 'Invalid budget';
            const location = ['point_code', 'reference'];
            const expectedResult = {
                error: `Invalid data`,
                value: '[object Object]',
                type: 'object',
            };

            const result = BusinessCheck.checkValue(customers, fields, range, error, location);

            chai.expect(result).to.be.eql(expectedResult);
            chai.expect(result).to.be.an('object');
        });
        it('should return a array if value is empty ', () => {
            const data = [
                {
                    timestamp: '2021-10-21T11:25:04.000Z',
                    directory_uid: 'a8216563d40f7e22b615de80f37a101a',
                    type: ' ',
                    reference: '20190301019FF4F10EB8',
                    point_code: '004674V',
                    crea_code: ' ',
                    status: undefined,
                    creation_date: '2019-03-01T10:59:36.000Z',
                    deadline: '2019-12-03T23:59:59.000Z',
                    campaign_start_date: '2019-03-01T10:55:48.000Z',
                },
            ];
            const fields = ['status'];
            const range = { expectedValue: 1, expectedtype: 'number' };
            const error = 'Invalid ';
            const location = ['point_code', 'reference'];
            const expectedResult = [
                {
                    error: `${error}`,
                    value: 'undefined',
                    type: `Value do not exist type: undefined`,
                    point_code: '004674V',
                    category_code: '20190301019FF4F10EB8',
                },
            ];
            const result = BusinessCheck.checkValue(data, fields, range, error, location);

            chai.expect(result).to.be.eql(expectedResult);
            chai.expect(result).to.be.an('array');
        });
        it('should return a array if there is no value for point_code', () => {
            const customer = [
                {
                    timestamp: '2020-11-25T05:21:53.000Z',
                    status: 1,
                    media_code: 'FRADSK004674V',
                    country_code: 'FRA',
                    media_shortcode: 'DSK004674V',
                    category_code: 'DSK',
                    group_code: 'DSK',
                    agency_code: 'DSK',
                    geometry_hash: '6493ab6024cf68c12c7128f898643e20',
                    prices: {
                        1: { budget: 420, impressions: 105000 },
                        2: { budget: 448, impressions: 112000 },
                        3: { budget: 476, impressions: 119000 },
                    },
                },
            ];
            const fields = ['status'];
            const range = { expectedValue: 1, expectedtype: 'number' };
            const error = 'Invalid Value';
            const location = ['point_code', 'category_code'];

            const expectedResult = [{ error: `${error}`, value: 'unknown', type: `Field doesn't exist` }];
            const result = BusinessCheck.checkValue(customer, fields, range, error, location);
            chai.expect(result).to.be.eql(expectedResult);
            chai.expect(result).to.be.an('array');
        });
        it('should return a array if there is no value for category_code', () => {
            const customer = [
                {
                    timestamp: '2020-11-25T05:21:53.000Z',
                    status: 1,
                    point_code: '004674V',
                    media_code: 'FRADSK004674V',
                    media_shortcode: 'DSK004674V',
                    group_code: 'DSK',
                    agency_code: 'DSK',
                    geometry_hash: '6493ab6024cf68c12c7128f898643e20',
                    prices: {
                        1: { budget: 420, impressions: 105000 },
                        2: { budget: 448, impressions: 112000 },
                        3: { budget: 476, impressions: 119000 },
                    },
                },
            ];
            const fields = ['status'];
            const range = { expectedValue: 1, expectedtype: 'number' };
            const error = 'Invalid Value';
            const location = ['point_code', 'reference'];

            const expectedResult = [{ error: `${error}`, value: 'unknown', type: `Field doesn't exist` }];
            const result = BusinessCheck.checkValue(customer, fields, range, error, location);
            chai.expect(result).to.be.eql(expectedResult);
            chai.expect(result).to.be.an('array');
        });
        it('should return a array if the fieldValue does not exist', () => {
            const customer = [
                {
                    timestamp: '2020-11-25T05:21:53.000Z',
                    point_code: '004674V',
                    media_code: 'FRADSK004674V',
                    media_shortcode: 'DSK004674V',
                    group_code: 'DSK',
                    category_code: 'DSK',
                    agency_code: 'DSK',
                    geometry_hash: '6493ab6024cf68c12c7128f898643e20',
                    prices: {
                        1: { budget: 420, impressions: 105000 },
                        2: { budget: 448, impressions: 112000 },
                        3: { budget: 476, impressions: 119000 },
                    },
                },
            ];
            const fields = ['status'];
            const range = { expectedValue: 1, expectedtype: 'number' };
            const error = 'Invalid Value';
            const location = ['point_code', 'category_code'];

            const expectedResult = [{ error: `${error}`, value: '[object Object]', type: `Field doesn't exist`, point_code: '004674V', category_code: 'DSK' }];
            const result = BusinessCheck.checkValue(customer, fields, range, error, location);
            chai.expect(result).to.be.eql(expectedResult);
            chai.expect(result).to.be.an('array');
        });
    });
});

const ToolsFiles = require('../src/tools/files');
const mocha = require('mocha');
const sinon = require('sinon');

const chai = require('chai');

describe('ToolsFiles', () => {
    '/Users/kevincourroux/dev/check_databases/resources/api.json';
    describe('ToolsFiles.loadFileAsJson', () => {
        it('should return a object if the path is connected with a json', () => {
            const filename = '/Users/kevincourroux/dev/check_databases/resources/api.json';
            const expectedResult = {
                toCheck: [
                    {
                        role: 'linked campaign',
                        api: 'campaigns',
                        route: '/campaigns/?status=1,5,7',
                        fields: ['details.provider', 'details.provider_data.id'],
                        location: ['campaign_code'],
                        condition: 'exists',
                        range: {},
                        error: 'Invalid campaign',
                    },
                    {
                        role: 'top-ten-report',
                        api: 'campaigns',
                        route: '/campaigns/info/?name=top-ten-report',
                        fields: 'details.sites',
                        location: ['campaign_code'],
                        condition: 'exists',
                        range: {},
                        error: 'Invalid top-ten-report',
                    },
                    {
                        role: 'metrics',
                        api: 'campaigns',
                        route: '/campaigns/metrics/?index.count=1000000',
                        fields: ['metrics.impressions', 'metrics.clicks', 'metrics'],
                        location: ['campaign_code', 'log_date'],
                        condition: 'exists',
                        range: {},
                        error: 'Invalid metrics',
                    },
                ],
            };

            const result = ToolsFiles.loadFileAsJson(filename);
            chai.expect(result).to.be.eql(expectedResult);
            chai.expect(result).to.be.an('object');
        });
    });
});

const { HttpApiV2, logger, env } = require('nodelib');
const http = new HttpApiV2();

const businessMail = require('../src/business/mail');

const mocha = require('mocha');
const sinon = require('sinon');
const chai = require('chai');

describe('businessMail', function () {
    this.beforeEach(() => {
        env.DOCGEN_URL = 'http://localhost:5151';
        env.MAILER_URL = 'http://localhost:5141';
        env.EMAILDEST = 'ryanborchani97@gmail.com ';
    });
    this.afterEach(() => {
        sinon.restore();
    });
    describe('businessMail.sendMailWithTemplate', (done) => {
        it('should send the mail', async () => {
            const emailDest = 'ryanborchani97@gmail.com';
            const emailFrom = 'support@adcleek.com';
            const template = 'checkDatabases';
            const data = {
                brand: 'ds',
                result: 'ryan',
            };

            businessMail.sendMailWithTemplate({ emailDest, emailFrom, template, data, attachmentName: null, attachmentContent: null }).then((res) => {
                const urlDocGen = env.DOCGEN_URL.concat('/email/', template);
                const bodyData = {
                    data: {
                        brand: data.brand,
                        result: data.result,
                    },
                };
                const httpGetStub = sinon.stub(HttpApiV2.prototype, 'post');
                const mailRes = httpGetStub.withArgs(urlDocGen, bodyData).resolves(res);
                const datamail = {
                    from: emailFrom,
                    dest: emailDest,
                    attachment: null,
                    subject: `Résultats de la vérification des données ${data.brand !== undefined ? data.brand : ''}`,
                    text: mailRes.data.text,
                    html: mailRes.data.html,
                    encode: {},
                };
                httpGetStub.withArgs(env.MAILER_URL, datamail).resolves({ message: 'E-mail envoyé avec succes' });
                done;
                chai.expect(result).to.be.an('object');
            });
        });
    });
    describe('businessMail.sendEmailWithTemplateCustomer', (done) => {
        it('should send the mail', async () => {
            brand = 'ds';
            fileter = [{ error: 'ryan' }];
            sinon.stub(businessMail, 'sendMailWithTemplate').resolves({ message: 'E-mail envoyé avec succes' });
            businessMail.sendEmailWithTemplateCustomer(brand, fileter).then((res) => {
                done;
                chai.expect(result).to.be.undefined;
            });
        });
    });
    describe('businessMail.sendEmailWithTemplate', (done) => {
        it('should send the mail', async () => {
            fileter = [{ error: 'ryan' }];
            sinon.stub(businessMail, 'sendMailWithTemplate').resolves({ message: 'E-mail envoyé avec succes' });
            businessMail.sendEmailWithTemplate(fileter).then((res) => {
                done;
                chai.expect(result).to.be.undefined;
            });
        });
    });
});

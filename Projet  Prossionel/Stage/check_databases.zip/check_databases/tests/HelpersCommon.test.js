const HelpersCommon = require('../src/business/helpers/common');
const mocha = require('mocha');
const sinon = require('sinon');
const chai = require('chai');

describe('HelpersCommon', () => {
    describe('HelpersCommon.getFieldValue', () => {
        it('should return a object if fieldValue exists', () => {
            const customers = [
                {
                    timestamp: '2020-11-25T05:21:53.000Z',
                    status: 1,
                    point_code: '004674V',
                    media_code: 'FRADSK004674V',
                    country_code: 'FRA',
                    media_shortcode: 'DSK004674V',
                    category_code: 'DSK',
                    group_code: 'DSK',
                    agency_code: 'DSK',
                    geometry_hash: '6493ab6024cf68c12c7128f898643e20',
                    prices: {
                        1: {
                            budget: 420,
                            impressions: 105000,
                        },
                        2: {
                            budget: 448,
                            impressions: 112000,
                        },
                        3: {
                            budget: 476,
                            impressions: 119000,
                        },
                    },
                },
                {
                    timestamp: '2020-11-25T05:21:53.000Z',
                    status: 1,
                    point_code: '004674V',
                    media_code: 'FRAMOB004674V',
                    country_code: 'FRA',
                    media_shortcode: 'MOB004674V',
                    category_code: 'MOB',
                    group_code: 'MOB',
                    agency_code: 'MOB',
                    geometry_hash: '6493ab6024cf68c12c7128f898643e20',
                    prices: {
                        1: {
                            budget: 546,
                            impressions: 91000,
                        },
                        2: {
                            budget: 588,
                            impressions: 98000,
                        },
                        3: {
                            budget: 630,
                            impressions: 105000,
                        },
                    },
                },
            ];
            const fields = ['prices', '1', 'budget'];
            const pc = 'point_code';
            const cc = 'category_code';
            const error = 'Invalid Value';

            const expectedResult = { fieldValues: [420, 546], pointcodes: ['004674V', '004674V'], categorycodes: ['DSK', 'MOB'], results: [] };

            const result = HelpersCommon.getFieldValue(customers, fields, pc, cc, error);
            chai.expect(result).to.be.eql(expectedResult);
            chai.expect(result).to.be.an('object');
        });
        it('should return a object if fieldValue does exist', () => {
            const customers = [
                {
                    timestamp: '2020-11-25T05:21:53.000Z',
                    status: 1,
                    media_code: 'FRADSK004674V',
                    country_code: 'FRA',
                    media_shortcode: 'DSK004674V',
                    group_code: 'DSK',
                    agency_code: 'DSK',
                    geometry_hash: '6493ab6024cf68c12c7128f898643e20',
                    prices: {
                        1: {
                            impressions: 105000,
                        },
                        2: {
                            budget: 448,
                            impressions: 112000,
                        },
                        3: {
                            budget: 476,
                            impressions: 119000,
                        },
                    },
                },
                {
                    timestamp: '2020-11-25T05:21:53.000Z',
                    status: 1,
                    media_code: 'FRAMOB004674V',
                    country_code: 'FRA',
                    media_shortcode: 'MOB004674V',
                    group_code: 'MOB',
                    agency_code: 'MOB',
                    geometry_hash: '6493ab6024cf68c12c7128f898643e20',
                    prices: {
                        1: {
                            impressions: 91000,
                        },
                        2: {
                            budget: 588,
                            impressions: 98000,
                        },
                        3: {
                            budget: 630,
                            impressions: 105000,
                        },
                    },
                },
            ];
            const fields = ['prices', '1', 'budget'];
            const pc = 'point_code';
            const cc = 'category_ccode';
            const error = 'Invalid Value';
            const expectedResult = {
                fieldValues: [{ impressions: 105000 }, { impressions: 91000 }],
                pointcodes: [undefined, undefined],
                categorycodes: [undefined, undefined],
                results: [
                    {
                        error: 'Invalid Value',
                        value: 'unknown',
                        type: "Field doesn't exist",
                    },
                    {
                        error: 'Invalid Value',
                        value: 'unknown',
                        type: "Field doesn't exist",
                    },
                    {
                        error: 'Invalid Value',
                        value: '[object Object]',
                        type: "Field doesn't exist",
                        point_code: 'undefined',
                        category_code: 'undefined',
                    },
                    {
                        error: 'Invalid Value',
                        value: 'unknown',
                        type: "Field doesn't exist",
                    },
                    {
                        error: 'Invalid Value',
                        value: 'unknown',
                        type: "Field doesn't exist",
                    },
                    {
                        error: 'Invalid Value',
                        value: '[object Object]',
                        type: "Field doesn't exist",
                        point_code: 'undefined',
                        category_code: 'undefined',
                    },
                ],
            };
            const result = HelpersCommon.getFieldValue(customers, fields, pc, cc, error);
            chai.expect(result).to.be.eql(expectedResult);
            chai.expect(result).to.be.an('object');
        });
    });
    describe('HelpersCommon.getLocationFirstValue', () => {
        it('should return a object with the value of point_code and a empty array', () => {
            const fieldValue = {
                timestamp: '2020-11-25T05:21:53.000Z',
                status: 1,
                point_code: '004674V',
                media_code: 'FRAADW004674V',
                country_code: 'FRA',
                media_shortcode: 'ADW004674V',
                category_code: 'ADW',
                group_code: 'ADW',
                agency_code: 'ADW',
                geometry_hash: '6493ab6024cf68c12c7128f898643e20',
                prices: {
                    1: { budget: 130, clicks: 200 },
                    2: { budget: 140, clicks: 215 },
                    3: { budget: 150, clicks: 231 },
                },
            };
            const point_code = 'point_code';
            const error = 'Invalid Value';
            const expectedResult = { pointcode: '004674V', warning: [] };
            const result = HelpersCommon.getLocationFirstValue(fieldValue, point_code, error);
            chai.expect(result).to.be.eql(expectedResult);
            chai.expect(result).to.be.an('object');
        });
        it('should return a object without the value of point_code and the a array of where is the error', () => {
            const fieldValue = {
                timestamp: '2020-11-25T05:21:53.000Z',
                status: 1,
                media_code: 'FRAADW004674V',
                country_code: 'FRA',
                media_shortcode: 'ADW004674V',
                category_code: 'ADW',
                group_code: 'ADW',
                agency_code: 'ADW',
                geometry_hash: '6493ab6024cf68c12c7128f898643e20',
                prices: {
                    1: { budget: 130, clicks: 200 },
                    2: { budget: 140, clicks: 215 },
                    3: { budget: 150, clicks: 231 },
                },
            };
            const point_code = 'point_code';
            const error = 'Invalid Value';
            const expectedResult = { pointcode: undefined, warning: [{ error: `${error}`, value: 'unknown', type: `Field doesn't exist` }] };
            const result = HelpersCommon.getLocationFirstValue(fieldValue, point_code, error);

            chai.expect(result).to.be.eql(expectedResult);
            chai.expect(result).to.be.an('object');
        });
    });
    describe('HelpersCommon.getLocationSecondValue', () => {
        it('should return a object with the value of point_code and a empty array', () => {
            const fieldValue = {
                timestamp: '2020-11-25T05:21:53.000Z',
                status: 1,
                point_code: '004674V',
                media_code: 'FRAADW004674V',
                country_code: 'FRA',
                media_shortcode: 'ADW004674V',
                category_code: 'ADW',
                group_code: 'ADW',
                agency_code: 'ADW',
                geometry_hash: '6493ab6024cf68c12c7128f898643e20',
                prices: {
                    1: { budget: 130, clicks: 200 },
                    2: { budget: 140, clicks: 215 },
                    3: { budget: 150, clicks: 231 },
                },
            };
            const category_code = 'category_code';
            const error = 'Invalid Value';
            const expectedResult = { categorycode: 'ADW', warnings: [] };
            const result = HelpersCommon.getLocationSecondValue(fieldValue, category_code, error);
            chai.expect(result).to.be.eql(expectedResult);
            chai.expect(result).to.be.an('object');
        });
        it('should return a object without the value of point_code and the a array of where is the error', () => {
            const fieldValue = {
                timestamp: '2020-11-25T05:21:53.000Z',
                status: 1,
                media_code: 'FRAADW004674V',
                country_code: 'FRA',
                media_shortcode: 'ADW004674V',
                group_code: 'ADW',
                agency_code: 'ADW',
                geometry_hash: '6493ab6024cf68c12c7128f898643e20',
                prices: {
                    1: { budget: 130, clicks: 200 },
                    2: { budget: 140, clicks: 215 },
                    3: { budget: 150, clicks: 231 },
                },
            };
            const category_code = 'category_code';
            const error = 'Invalid Value';
            const expectedResult = { categorycode: undefined, warnings: [{ error: `${error}`, value: 'unknown', type: `Field doesn't exist` }] };
            const result = HelpersCommon.getLocationSecondValue(fieldValue, category_code, error);

            chai.expect(result).to.be.eql(expectedResult);
            chai.expect(result).to.be.an('object');
        });
    });
});

const BusinessDataType = require('../src/business/dataType');
const mocha = require('mocha');
const sinon = require('sinon');

const chai = require('chai');

describe('BusinessDataType', () => {
    describe('BusinessDataType.isNumber', () => {
        it('should return a object if the value is a number', function () {
            const customer = [
                {
                    timestamp: '2020-11-25T05:21:53.000Z',
                    status: 1,
                    point_code: '004674V',
                    media_code: 'FRADSK004674V',
                    country_code: 'FRA',
                    media_shortcode: 'DSK004674V',
                    category_code: 'DSK',
                    group_code: 'DSK',
                    agency_code: 'DSK',
                    geometry_hash: '6493ab6024cf68c12c7128f898643e20',
                    prices: {
                        1: { budget: 420, impressions: 105000 },
                        2: { budget: 448, impressions: 112000 },
                        3: { budget: 476, impressions: 119000 },
                    },
                },
            ];
            const fields = ['prices', '2', 'budget'];
            const range = { expectedtype: 'number' };
            const error = 'Invalid number';
            const location = ['point_code', 'category_code'];
            const expectedResult = { success: true };

            const result = BusinessDataType.isNumber(customer, fields, range, error, location);
            chai.expect(result).to.be.eql(expectedResult);
            chai.expect(result).to.be.an('object');
        });
        it('should return an object if the value is a string that can be converted to a number', () => {
            const customer = [
                {
                    timestamp: '2020-11-25T05:21:53.000Z',
                    status: 1,
                    point_code: '004674V',
                    media_code: 'FRADSK004674V',
                    country_code: 'FRA',
                    media_shortcode: 'DSK004674V',
                    category_code: 'DSK',
                    group_code: 'DSK',
                    agency_code: 'DSK',
                    geometry_hash: '6493ab6024cf68c12c7128f898643e20',
                    prices: {
                        1: { budget: '80', impressions: 105000 },
                        2: { budget: 448, impressions: 112000 },
                        3: { budget: 476, impressions: 119000 },
                    },
                },
            ];
            const fields = ['prices', '1', 'budget'];
            const range = { expectedtype: 'number' };
            const error = 'Invalid number';
            const location = ['point_code', 'category_code'];
            const expectedResult = { success: true };

            const result = BusinessDataType.isNumber(customer, fields, range, error, location);
            chai.expect(result).to.be.eql(expectedResult);
            chai.expect(result).to.be.an('object');
        });
        it('should return an array if the value is a string that cannot be converted to a number or another different type of number and string', () => {
            const customer = [
                {
                    timestamp: '2020-11-25T05:21:53.000Z',
                    status: 1,
                    point_code: '004674V',
                    media_code: 'FRADSK004674V',
                    country_code: 'FRA',
                    media_shortcode: 'DSK004674V',
                    category_code: 'DSK',
                    group_code: 'DSK',
                    agency_code: 'DSK',
                    geometry_hash: '6493ab6024cf68c12c7128f898643e20',
                    prices: {
                        1: { budget: 420, impressions: 105000 },
                        2: { budget: 448, impressions: 112000 },
                        3: { budget: "c'est pas un nombre", impressions: 119000 },
                    },
                },
            ];
            const fields = ['prices', '3', 'budget'];
            const range = { expectedtype: 'number' };
            const error = 'Invalid number';
            const location = ['point_code', 'category_code'];
            const expectedResult = [
                {
                    error: `${error}`,
                    value: "c'est pas un nombre",
                    type: 'Invalid number conversion',
                    point_code: '004674V',
                    category_code: 'DSK',
                },
            ];
            const result = BusinessDataType.isNumber(customer, fields, range, error, location);

            chai.expect(result).to.be.eql(expectedResult);
            chai.expect(result).to.be.an('array');
        });
        it('should return a array if value is empty ', () => {
            const customer = [
                {
                    timestamp: '2020-11-25T05:21:53.000Z',
                    status: 1,
                    media_code: 'FRADSK004674V',
                    country_code: 'FRA',
                    media_shortcode: 'DSK004674V',
                    category_code: 'DSK',
                    group_code: 'DSK',
                    agency_code: 'DSK',
                    geometry_hash: '6493ab6024cf68c12c7128f898643e20',
                    prices: {
                        1: { budget: 420, impressions: 105000 },
                        2: { budget: 448, impressions: 112000 },
                        3: { budget: '', impressions: '' },
                    },
                },
            ];
            const fields = ['prices', '3', 'impressions'];
            const range = { expectedtype: 'number' };
            const error = 'Invalid number';
            const location = ['point_code', 'category_code'];
            const expectedResult = [
                {
                    error: `${error}`,
                    value: 'unknown',
                    type: "Field doesn't exist",
                },
            ];
            const result = BusinessDataType.isNumber(customer, fields, range, error, location);
            chai.expect(result).to.be.eql(expectedResult);
            chai.expect(result).to.be.an('array');
        });
        it('should return a object if the customer is empty', () => {
            const customers = { data: [{}] };
            const fields = ['prices', '3', 'budget'];
            const range = { low: '100', high: '2000', expectedtype: 'number' };
            const error = 'Invalid budget';
            const location = ['point_code', 'category_code'];
            const expectedResult = { error: 'Invalid data' };

            const result = BusinessDataType.isNumber(customers, fields, range, error, location);

            chai.expect(result).to.be.eql(expectedResult);
            chai.expect(result).to.be.an('object');
        });
        it('should return a array if there is no value for point_code', () => {
            const customer = [
                {
                    timestamp: '2020-11-25T05:21:53.000Z',
                    status: 1,
                    media_code: 'FRADSK004674V',
                    country_code: 'FRA',
                    media_shortcode: 'DSK004674V',
                    category_code: 'DSK',
                    group_code: 'DSK',
                    agency_code: 'DSK',
                    geometry_hash: '6493ab6024cf68c12c7128f898643e20',
                    prices: {
                        1: { budget: 420, impressions: 105000 },
                        2: { budget: 448, impressions: 112000 },
                        3: { budget: 476, impressions: 119000 },
                    },
                },
            ];
            const fields = ['status'];
            const range = { expectedValue: 1, expectedtype: 'number' };
            const error = 'Invalid Value';
            const location = ['point_code', 'category_code'];

            const expectedResult = [{ error: `${error}`, value: 'unknown', type: `Field doesn't exist` }];
            const result = BusinessDataType.isNumber(customer, fields, range, error, location);
            chai.expect(result).to.be.eql(expectedResult);
            chai.expect(result).to.be.an('array');
        });
        it('should return a array if there is no value for category_code', () => {
            const customer = [
                {
                    timestamp: '2020-11-25T05:21:53.000Z',
                    status: 1,
                    point_code: '004674V',
                    media_code: 'FRADSK004674V',
                    media_shortcode: 'DSK004674V',
                    group_code: 'DSK',
                    agency_code: 'DSK',
                    geometry_hash: '6493ab6024cf68c12c7128f898643e20',
                    prices: {
                        1: { budget: 420, impressions: 105000 },
                        2: { budget: 448, impressions: 112000 },
                        3: { budget: 476, impressions: 119000 },
                    },
                },
            ];
            const fields = ['status'];
            const range = { expectedValue: 1, expectedtype: 'number' };
            const error = 'Invalid Value';
            const location = ['point_code', 'category_code'];

            const expectedResult = [{ error: `${error}`, value: 'unknown', type: `Field doesn't exist` }];
            const result = BusinessDataType.isNumber(customer, fields, range, error, location);
            chai.expect(result).to.be.eql(expectedResult);
            chai.expect(result).to.be.an('array');
        });
        it('should return a array if the fieldValue does not exist', () => {
            const customer = [
                {
                    timestamp: '2020-11-25T05:21:53.000Z',
                    point_code: '004674V',
                    media_code: 'FRADSK004674V',
                    media_shortcode: 'DSK004674V',
                    group_code: 'DSK',
                    category_code: 'DSK',
                    agency_code: 'DSK',
                    geometry_hash: '6493ab6024cf68c12c7128f898643e20',
                    prices: {
                        1: { budget: 420, impressions: 105000 },
                        2: { budget: 448, impressions: 112000 },
                        3: { budget: 476, impressions: 119000 },
                    },
                },
            ];
            const fields = ['status'];
            const range = { expectedValue: 1, expectedtype: 'number' };
            const error = 'Invalid Value';
            const location = ['point_code', 'category_code'];

            const expectedResult = [{ error: `${error}`, value: '[object Object]', type: `Field doesn't exist`, point_code: '004674V', category_code: 'DSK' }];
            const result = BusinessDataType.isNumber(customer, fields, range, error, location);
            chai.expect(result).to.be.eql(expectedResult);
            chai.expect(result).to.be.an('array');
        });
    });
    describe('BusinessDataType.isString', () => {
        it('should return a object if the value is a string  ', function () {
            const customer = [
                {
                    timestamp: '2020-11-25T05:21:53.000Z',
                    status: 1,
                    point_code: '004674V',
                    media_code: 'FRADSK004674V',
                    country_code: 'FRA',
                    media_shortcode: 'DSK004674V',
                    category_code: 'DSK',
                    group_code: 'DSK',
                    agency_code: 'DSK',
                    geometry_hash: '6493ab6024cf68c12c7128f898643e20',
                    prices: {
                        1: { budget: 420, impressions: 'Ryan' },
                        2: { budget: 448, impressions: 112000 },
                        3: { budget: 476, impressions: 119000 },
                    },
                },
            ];
            const fields = ['prices', '1', 'impressions'];
            const range = { expectedtype: 'string' };
            const error = 'Invalid string';
            const location = ['point_code', 'category_code'];
            const expectedResult = { success: true };
            const result = BusinessDataType.isString(customer, fields, range, error, location);
            chai.expect(result).to.be.eql(expectedResult);
            chai.expect(result).to.be.an('object');
        });
        it('should return a array if value is not a string ', () => {
            const customer = [
                {
                    timestamp: '2020-11-25T05:21:53.000Z',
                    status: 1,
                    point_code: '004674V',
                    media_code: 'FRADSK004674V',
                    country_code: 'FRA',
                    media_shortcode: 'DSK004674V',
                    category_code: 'DSK',
                    group_code: 'DSK',
                    agency_code: 'DSK',
                    geometry_hash: '6493ab6024cf68c12c7128f898643e20',
                    prices: {
                        1: { budget: 420, impressions: 105000 },
                        2: { budget: 448, impressions: 112000 },
                        3: { budget: 476, impressions: 222234 },
                    },
                },
            ];
            const fields = ['prices', '3', 'impressions'];
            const range = { expectedtype: 'string' };
            const error = 'Invalid string';
            const location = ['point_code', 'category_code'];
            const expectedResult = [
                {
                    error: `${error}`,
                    value: '222234',
                    type: `type mismatch received number, expected: ${range.expectedtype}`,
                    point_code: '004674V',
                    category_code: 'DSK',
                },
            ];
            const result = BusinessDataType.isString(customer, fields, range, error, location);
            chai.expect(result).to.be.eql(expectedResult);
            chai.expect(result).to.be.an('array');
        });
        it('should return a object if the customer is empty', () => {
            const customer = { data: [{}] };
            const fields = ['prices', '3', 'budget'];
            const range = { expectedtype: 'string' };
            const error = 'Invalid string';
            const location = ['point_code', 'category_code'];
            const expectedResult = {
                error: `Invalid data`,
            };
            const result = BusinessDataType.isString(customer, fields, range, error, location);
            chai.expect(result).to.be.eql(expectedResult);
            chai.expect(result).to.be.an('object');
        });
        it('should return a array if there is no value for point_code', () => {
            const customer = [
                {
                    timestamp: '2020-11-25T05:21:53.000Z',
                    status: '1',
                    media_code: 'FRADSK004674V',
                    country_code: 'FRA',
                    media_shortcode: 'DSK004674V',
                    category_code: 'DSK',
                    group_code: 'DSK',
                    agency_code: 'DSK',
                    geometry_hash: '6493ab6024cf68c12c7128f898643e20',
                    prices: {
                        1: { budget: 420, impressions: 105000 },
                        2: { budget: 448, impressions: 112000 },
                        3: { budget: 476, impressions: 119000 },
                    },
                },
            ];
            const fields = ['status'];
            const range = { expectedtype: 'number' };
            const error = 'Invalid string';
            const location = ['point_code', 'category_code'];
            const expectedResult = [{ error: `${error}`, value: 'unknown', type: `Field doesn't exist` }];
            const result = BusinessDataType.isString(customer, fields, range, error, location);
            chai.expect(result).to.be.eql(expectedResult);
            chai.expect(result).to.be.an('array');
        });
        it('should return a array if there is no value for category_code', () => {
            const customer = [
                {
                    timestamp: '2020-11-25T05:21:53.000Z',
                    status: 1,
                    point_code: '004674V',
                    media_code: 'FRADSK004674V',
                    media_shortcode: 'DSK004674V',
                    group_code: 'DSK',
                    agency_code: 'DSK',
                    geometry_hash: '6493ab6024cf68c12c7128f898643e20',
                    prices: {
                        1: { budget: 420, impressions: 105000 },
                        2: { budget: 448, impressions: 112000 },
                        3: { budget: 476, impressions: 119000 },
                    },
                },
            ];
            const fields = ['status'];
            const range = { expectedValue: 1, expectedtype: 'number' };
            const error = 'Invalid Value';
            const location = ['point_code', 'category_code'];
            const expectedResult = [{ error: `${error}`, value: 'unknown', type: `Field doesn't exist` }];
            const result = BusinessDataType.isString(customer, fields, range, error, location);
            chai.expect(result).to.be.eql(expectedResult);
            chai.expect(result).to.be.an('array');
        });
        it('should return a array if the fieldValue does not exist', () => {
            const customer = [
                {
                    timestamp: '2020-11-25T05:21:53.000Z',
                    point_code: '004674V',
                    media_code: 'FRADSK004674V',
                    media_shortcode: 'DSK004674V',
                    group_code: 'DSK',
                    category_code: 'DSK',
                    agency_code: 'DSK',
                    geometry_hash: '6493ab6024cf68c12c7128f898643e20',
                    prices: {
                        1: { budget: 420, impressions: 105000 },
                        2: { budget: 448, impressions: 112000 },
                        3: { budget: 476, impressions: 119000 },
                    },
                },
            ];
            const fields = ['status'];
            const range = { expectedValue: 1, expectedtype: 'number' };
            const error = 'Invalid Value';
            const location = ['point_code', 'category_code'];
            const expectedResult = [{ error: `${error}`, value: '[object Object]', type: `Field doesn't exist`, point_code: '004674V', category_code: 'DSK' }];
            const result = BusinessDataType.isString(customer, fields, range, error, location);
            chai.expect(result).to.be.eql(expectedResult);
            chai.expect(result).to.be.an('array');
        });
    });
    describe('BusinessDataType.isBoolean', () => {
        it('should return a object if the value is a boolean ', () => {
            const customer = [
                {
                    timestamp: '2021-10-21T11:25:04.000Z',
                    directory_uid: 'a8216563d40f7e22b615de80f37a101a',
                    type: ' ',
                    reference: '20190301019FF4F10EB8',
                    point_code: '004674V',
                    crea_code: ' ',
                    value: true,
                    status: 1,
                    creation_date: '2019-03-01T10:59:36.000Z',
                    deadline: '2019-12-03T23:59:59.000Z',
                    campaign_start_date: '2019-03-01T10:55:48.000Z',
                },
            ];
            const fields = ['value'];
            const range = { expectedtype: 'boolean' };
            const error = 'Invalid boolean';
            const location = ['point_code', 'reference'];

            const expectedResult = { success: true };

            const result = BusinessDataType.isBoolean(customer, fields, range, error, location);

            chai.expect(result).to.be.eql(expectedResult);
            chai.expect(result).to.be.an('object');
        });
        it('should return an object if the value is a string that can be converted to a boolean', () => {
            const data = [
                {
                    timestamp: '2021-10-21T11:25:04.000Z',
                    directory_uid: 'a8216563d40f7e22b615de80f37a101a',
                    type: ' ',
                    reference: '20190301019FF4F10EB8',
                    point_code: '004674V',
                    crea_code: ' ',
                    status: 'true',
                    creation_date: '2019-03-01T10:59:36.000Z',
                    deadline: '2019-12-03T23:59:59.000Z',
                    campaign_start_date: '2019-03-01T10:55:48.000Z',
                },
            ];
            const fields = ['status'];
            const range = { expectedtype: 'boolean' };
            const error = 'Invalid boolean';
            const location = ['point_code', 'reference'];

            const expectedResult = { success: true };

            const result = BusinessDataType.isBoolean(data, fields, range, error, location);
            chai.expect(result).to.be.eql(expectedResult);
            chai.expect(result).to.be.an('object');
        });
        it('should return an array if the value is a string that cannot be converted to a boolean ', () => {
            const quotation = [
                {
                    timestamp: '2021-10-21T11:25:04.000Z',
                    directory_uid: 'a8216563d40f7e22b615de80f37a101a',
                    type: ' ',
                    reference: '20190301019FF4F10EB8',
                    point_code: '004674V',
                    crea_code: ' ',
                    status: 'Ryan',
                    creation_date: '2019-03-01T10:59:36.000Z',
                    deadline: '2019-12-03T23:59:59.000Z',
                    campaign_start_date: '2019-03-01T10:55:48.000Z',
                },
            ];
            const fields = ['status'];
            const range = { expectedtype: 'string' };
            const error = 'Invalid';
            const location = ['point_code', 'reference'];

            const expectedResult = [
                {
                    error: 'Invalid',
                    value: 'ryan',
                    type: `Invalid boolean value`,
                    point_code: '004674V',
                    category_code: '20190301019FF4F10EB8',
                },
            ];
            const result = BusinessDataType.isBoolean(quotation, fields, range, error, location);
            chai.expect(result).to.be.eql(expectedResult);
            chai.expect(result).to.be.an('array');
        });
        it('should return an array if the value is not a boolean or a string', () => {
            const quotation = [
                {
                    timestamp: '2021-10-21T11:25:04.000Z',
                    directory_uid: 'a8216563d40f7e22b615de80f37a101a',
                    type: ' ',
                    reference: '20190301019FF4F10EB8',
                    point_code: '004674V',
                    crea_code: ' ',
                    status: 1,
                    creation_date: '2019-03-01T10:59:36.000Z',
                    deadline: '2019-12-03T23:59:59.000Z',
                    campaign_start_date: '2019-03-01T10:55:48.000Z',
                },
            ];
            const fields = ['status'];
            const range = { expectedtype: 'boolean' };
            const error = 'Invalid';
            const location = ['point_code', 'reference'];

            const expectedResult = [
                {
                    error: 'Invalid',
                    value: '1',
                    type: `type mismatch received number, expected: ${range.expectedtype}`,
                    point_code: '004674V',
                    category_code: '20190301019FF4F10EB8',
                },
            ];
            const result = BusinessDataType.isBoolean(quotation, fields, range, error, location);
            chai.expect(result).to.be.eql(expectedResult);
            chai.expect(result).to.be.an('array');
        });
        it('should return a object if the customer is empty', () => {
            const customers = { data: [{}] };
            const fields = ['prices', '3', 'budget'];
            const range = { expectedtype: 'boolean' };
            const error = 'Invalid boolean';
            const location = ['point_code', 'category_code'];
            const expectedResult = {
                error: `Invalid data`,
            };

            const result = BusinessDataType.isBoolean(customers, fields, range, error, location);

            chai.expect(result).to.be.eql(expectedResult);
            chai.expect(result).to.be.an('object');
        });
        it('should return a array if there is no value for point_code', () => {
            const customer = [
                {
                    timestamp: '2020-11-25T05:21:53.000Z',
                    status: 1,
                    media_code: 'FRADSK004674V',
                    country_code: 'FRA',
                    media_shortcode: 'DSK004674V',
                    category_code: 'DSK',
                    group_code: 'DSK',
                    agency_code: 'DSK',
                    geometry_hash: '6493ab6024cf68c12c7128f898643e20',
                    prices: {
                        1: { budget: 420, impressions: 105000 },
                        2: { budget: 448, impressions: 112000 },
                        3: { budget: 476, impressions: 119000 },
                    },
                },
            ];
            const fields = ['status'];
            const range = { expectedValue: 1, expectedtype: 'number' };
            const error = 'Invalid Value';
            const location = ['point_code', 'category_code'];

            const expectedResult = [{ error: `${error}`, value: 'unknown', type: `Field doesn't exist` }];
            const result = BusinessDataType.isBoolean(customer, fields, range, error, location);
            chai.expect(result).to.be.eql(expectedResult);
            chai.expect(result).to.be.an('array');
        });
        it('should return a array if there is no value for category_code', () => {
            const customer = [
                {
                    timestamp: '2020-11-25T05:21:53.000Z',
                    status: 1,
                    point_code: '004674V',
                    media_code: 'FRADSK004674V',
                    media_shortcode: 'DSK004674V',
                    group_code: 'DSK',
                    agency_code: 'DSK',
                    geometry_hash: '6493ab6024cf68c12c7128f898643e20',
                    prices: {
                        1: { budget: 420, impressions: 105000 },
                        2: { budget: 448, impressions: 112000 },
                        3: { budget: 476, impressions: 119000 },
                    },
                },
            ];
            const fields = ['status'];
            const range = { expectedValue: 1, expectedtype: 'number' };
            const error = 'Invalid Value';
            const location = ['point_code', 'category_code'];

            const expectedResult = [{ error: `${error}`, value: 'unknown', type: `Field doesn't exist` }];
            const result = BusinessDataType.isBoolean(customer, fields, range, error, location);
            chai.expect(result).to.be.eql(expectedResult);
            chai.expect(result).to.be.an('array');
        });
        it('should return a array if the fieldValue does not exist', () => {
            const customer = [
                {
                    timestamp: '2020-11-25T05:21:53.000Z',
                    point_code: '004674V',
                    media_code: 'FRADSK004674V',
                    media_shortcode: 'DSK004674V',
                    group_code: 'DSK',
                    category_code: 'DSK',
                    agency_code: 'DSK',
                    geometry_hash: '6493ab6024cf68c12c7128f898643e20',
                    prices: {
                        1: { budget: 420, impressions: 105000 },
                        2: { budget: 448, impressions: 112000 },
                        3: { budget: 476, impressions: 119000 },
                    },
                },
            ];
            const fields = ['status'];
            const range = { expectedValue: 1, expectedtype: 'number' };
            const error = 'Invalid Value';
            const location = ['point_code', 'category_code'];

            const expectedResult = [{ error: `${error}`, value: '[object Object]', type: `Field doesn't exist`, point_code: '004674V', category_code: 'DSK' }];
            const result = BusinessDataType.isBoolean(customer, fields, range, error, location);
            chai.expect(result).to.be.eql(expectedResult);
            chai.expect(result).to.be.an('array');
        });
    });
    describe('BusinessDataType.isNumber', () => {
        it('should return a object if the value is a array', function () {
            const customer = [
                {
                    name: 'availableMedias',
                    point_code: 'Array',
                    category_code: 'test',
                    value: ['PQR', 'PHR', 'RAD', 'AFF', 'CIN', 'ISA', 'DSK', 'MOB', 'FBK', 'ADW', 'SMS', 'VID', 'WTO', 'LIN'],
                    label: 'Médias disponibles',
                    type: 'array',
                    updated_at: '2021-08-27T11:06:54.000Z',
                },
            ];
            const fields = ['value'];
            const range = { expectedtype: 'array' };
            const error = 'Invalid array';
            const location = ['point_code', 'category_code'];
            const expectedResult = { success: true };

            const result = BusinessDataType.isArray(customer, fields, range, error, location);
            chai.expect(result).to.be.eql(expectedResult);
            chai.expect(result).to.be.an('object');
        });
        it('should return an object if the value is a string that can be converted to a array', () => {
            const customer = [
                {
                    name: 'availableMedias',
                    point_code: 'Array',
                    category_code: 'test',
                    value: '["PQR","PHR","RAD","AFF","CIN","ISA","DSK","MOB","FBK","ADW","SMS","VID","WTO","LIN"]',
                    label: 'Médias disponibles',
                    type: 'array',
                    updated_at: '2021-08-27T11:06:54.000Z',
                },
            ];
            const fields = ['value'];
            const range = { expectedtype: 'array' };
            const error = 'Invalid array';
            const location = ['point_code', 'category_code'];
            const expectedResult = { success: true };

            const result = BusinessDataType.isArray(customer, fields, range, error, location);
            chai.expect(result).to.be.eql(expectedResult);
            chai.expect(result).to.be.an('object');
        });
        it('should return an array if the value is a string that cannot be converted to a number or another different type of number and string', () => {
            const customer = [
                {
                    name: 'availableMedias',
                    point_code: 'Array',
                    category_code: 'test',
                    value: "['PQR', 'PHR', 'RAD', 'AFF', 'CIN', 'ISA', 'DSK', 'MOB', 'FBK', 'ADW', 'SMS', 'VID', 'WTO', 'LIN']",
                    label: 'Médias disponibles',
                    type: 'array',
                    updated_at: '2021-08-27T11:06:54.000Z',
                },
            ];
            const fields = ['value'];
            const range = { expectedtype: 'array' };
            const error = 'Invalid array';
            const location = ['point_code', 'category_code'];
            const expectedResult = [
                {
                    error: `${error}`,
                    value: "['PQR', 'PHR', 'RAD', 'AFF', 'CIN', 'ISA', 'DSK', 'MOB', 'FBK', 'ADW', 'SMS', 'VID', 'WTO', 'LIN']",
                    type: 'Invalid array conversion',
                    point_code: 'Array',
                    category_code: 'test',
                },
            ];
            const result = BusinessDataType.isArray(customer, fields, range, error, location);
            chai.expect(result).to.be.eql(expectedResult);
            chai.expect(result).to.be.an('array');
        });
        it('should return an array if the value is a string that cannot be converted to a number or another different type of number and string', () => {
            const customer = [
                {
                    name: 'availableMedias',
                    point_code: 'Array',
                    category_code: 'test',
                    value: true,
                    label: 'Médias disponibles',
                    type: 'array',
                    updated_at: '2021-08-27T11:06:54.000Z',
                },
            ];
            const fields = ['value'];
            const range = { expectedtype: 'array' };
            const error = 'Invalid array';
            const location = ['point_code', 'category_code'];
            const expectedResult = [
                {
                    error: `${error}`,
                    value: 'true',
                    type: `type mismatch received boolean, expected: ${range.expectedtype}`,
                    point_code: 'Array',
                    category_code: 'test',
                },
            ];
            const result = BusinessDataType.isArray(customer, fields, range, error, location);
            chai.expect(result).to.be.eql(expectedResult);
            chai.expect(result).to.be.an('array');
        });
        it('should return a array if value is empty ', () => {
            const customer = { data: [{}] };
            const fields = ['value'];
            const range = { expectedtype: 'array' };
            const error = 'Invalid array';
            const location = ['point_code', 'category_code'];
            const expectedResult = { error: 'Invalid data' };
            const result = BusinessDataType.isArray(customer, fields, range, error, location);
            chai.expect(result).to.be.eql(expectedResult);
            chai.expect(result).to.be.an('object');
        });
        it('should return a array if there is no value for point_code', () => {
            const customer = [
                {
                    name: 'availableMedias',
                    category_code: 'test',
                    value: ['PQR', 'PHR', 'RAD', 'AFF', 'CIN', 'ISA', 'DSK', 'MOB', 'FBK', 'ADW', 'SMS', 'VID', 'WTO', 'LIN'],
                    label: 'Médias disponibles',
                    type: 'array',
                    updated_at: '2021-08-27T11:06:54.000Z',
                },
            ];
            const fields = ['value'];
            const range = { expectedtype: 'array' };
            const error = 'Invalid array';
            const location = ['point_code', 'category_code'];

            const expectedResult = [{ error: `${error}`, value: 'unknown', type: `Field doesn't exist` }];
            const result = BusinessDataType.isArray(customer, fields, range, error, location);
            chai.expect(result).to.be.eql(expectedResult);
            chai.expect(result).to.be.an('array');
        });
        it('should return a array if there is no value for category_code', () => {
            const customer = [
                {
                    name: 'availableMedias',
                    point_code: 'Array',
                    value: ['PQR', 'PHR', 'RAD', 'AFF', 'CIN', 'ISA', 'DSK', 'MOB', 'FBK', 'ADW', 'SMS', 'VID', 'WTO', 'LIN'],
                    label: 'Médias disponibles',
                    type: 'array',
                    updated_at: '2021-08-27T11:06:54.000Z',
                },
            ];
            const fields = ['value'];
            const range = { expectedtype: 'array' };
            const error = 'Invalid array';
            const location = ['point_code', 'category_code'];

            const expectedResult = [{ error: `${error}`, value: 'unknown', type: `Field doesn't exist` }];
            const result = BusinessDataType.isArray(customer, fields, range, error, location);
            chai.expect(result).to.be.eql(expectedResult);
            chai.expect(result).to.be.an('array');
        });
        it('should return a array if the fieldValue does not exist', () => {
            const customer = [
                {
                    name: 'availableMedias',
                    point_code: 'Array',
                    category_code: 'test',
                    label: 'Médias disponibles',
                    type: 'array',
                    updated_at: '2021-08-27T11:06:54.000Z',
                },
            ];
            const fields = ['array'];
            const range = { expectedtype: 'array' };
            const error = 'Invalid array';
            const location = ['point_code', 'category_code'];

            const expectedResult = [{ error: `${error}`, value: '[object Object]', type: `Field doesn't exist`, point_code: 'Array', category_code: 'test' }];
            const result = BusinessDataType.isArray(customer, fields, range, error, location);
            chai.expect(result).to.be.eql(expectedResult);
            chai.expect(result).to.be.an('array');
        });
    });
    describe('BusinessDataType.isJson', () => {
        it('should return a object if the value is a json', () => {
            const customer = [
                {
                    name: 'hub_indicator',
                    point_code: 'Json',
                    category_code: 'Test',
                    value: { key: 'potential_amc', translation: 'nvQuota' },
                    label: 'Clé indicateur',
                    type: 'json',
                    updated_at: '2022-11-25T16:59:54.000Z',
                },
            ];
            const fields = ['value'];
            const range = { expectedtype: 'json' };
            const error = 'Invalid json';
            const location = ['point_code', 'category_code'];
            const expectedResult = { success: true };

            const result = BusinessDataType.isJson(customer, fields, range, error, location);
            chai.expect(result).to.be.eql(expectedResult);
            chai.expect(result).to.be.an('object');
        });
        it('should return a object if the value is a string that can be converted to a json', () => {
            const customer = [
                {
                    name: 'hub_indicator',
                    point_code: 'Json',
                    category_code: 'Test',
                    value: '{"key": "potential_amc", "translation": "nvQuota"}',
                    label: 'Clé indicateur',
                    type: 'json',
                    updated_at: '2022-11-25T16:59:54.000Z',
                },
            ];
            const fields = ['value'];
            const range = { expectedtype: 'json' };
            const error = 'Invalid json';
            const location = ['point_code', 'category_code'];
            const expectedResult = { success: true };

            const result = BusinessDataType.isJson(customer, fields, range, error, location);
            chai.expect(result).to.be.eql(expectedResult);
            chai.expect(result).to.be.an('object');
        });
        it('should return a array if the value is a string that cannot be converted to a json', () => {
            const customer = [
                {
                    name: 'hub_indicator',
                    point_code: 'Json',
                    category_code: 'Test',
                    value: "{'key': 'potential_amc', 'translation': 'nvQuota'}",
                    label: 'Clé indicateur',
                    type: 'json',
                    updated_at: '2022-11-25T16:59:54.000Z',
                },
            ];
            const fields = ['value'];
            const range = { expectedtype: 'json' };
            const error = 'Invalid json';
            const location = ['point_code', 'category_code'];
            const expectedResult = [
                {
                    error: `${error}`,
                    value: "{'key': 'potential_amc', 'translation': 'nvQuota'}",
                    type: `Invalid JSON format`,
                    point_code: 'Json',
                    category_code: 'Test',
                },
            ];

            const result = BusinessDataType.isJson(customer, fields, range, error, location);
            chai.expect(result).to.be.eql(expectedResult);
            chai.expect(result).to.be.an('array');
        });
        it('should return a array if the value is not a sting or a object', () => {
            const customer = [
                {
                    name: 'hub_indicator',
                    point_code: 'Json',
                    category_code: 'Test',
                    value: true,
                    label: 'Clé indicateur',
                    type: 'json',
                    updated_at: '2022-11-25T16:59:54.000Z',
                },
            ];
            const fields = ['value'];
            const range = { expectedtype: 'json' };
            const error = 'Invalid json';
            const location = ['point_code', 'category_code'];
            const expectedResult = [
                {
                    error: `${error}`,
                    value: 'true',
                    type: `type mismatch received boolean, expected: ${range.expectedtype}`,
                    point_code: 'Json',
                    category_code: 'Test',
                },
            ];

            const result = BusinessDataType.isJson(customer, fields, range, error, location);
            chai.expect(result).to.be.eql(expectedResult);
            chai.expect(result).to.be.an('array');
        });
        it('should return a array if there is no value for point_code', () => {
            const customer = [
                {
                    name: 'hub_indicator',
                    category_code: 'Test',
                    value: { key: 'potential_amc', translation: 'nvQuota' },
                    label: 'Clé indicateur',
                    type: 'json',
                    updated_at: '2022-11-25T16:59:54.000Z',
                },
            ];
            const fields = ['value'];
            const range = { expectedtype: 'json' };
            const error = 'Invalid json';
            const location = ['point_code', 'category_code'];

            const expectedResult = [{ error: `${error}`, value: 'unknown', type: `Field doesn't exist` }];
            const result = BusinessDataType.isJson(customer, fields, range, error, location);
            chai.expect(result).to.be.eql(expectedResult);
            chai.expect(result).to.be.an('array');
        });
        it('should return a array if there is no value for category_code', () => {
            const customer = [
                {
                    name: 'hub_indicator',
                    point_code: 'Json',
                    value: { key: 'potential_amc', translation: 'nvQuota' },
                    label: 'Clé indicateur',
                    type: 'json',
                    updated_at: '2022-11-25T16:59:54.000Z',
                },
            ];
            const fields = ['value'];
            const range = { expectedtype: 'array' };
            const error = 'Invalid array';
            const location = ['point_code', 'category_code'];

            const expectedResult = [{ error: `${error}`, value: 'unknown', type: `Field doesn't exist` }];
            const result = BusinessDataType.isJson(customer, fields, range, error, location);
            chai.expect(result).to.be.eql(expectedResult);
            chai.expect(result).to.be.an('array');
        });
        it('should return a array if the fieldValue does not exist', () => {
            const customer = [
                {
                    name: 'hub_indicator',
                    point_code: 'Json',
                    category_code: 'Test',
                    label: 'Clé indicateur',
                    type: 'json',
                    updated_at: '2022-11-25T16:59:54.000Z',
                },
            ];
            const fields = ['array'];
            const range = { expectedtype: 'object' };
            const error = 'Invalid json';
            const location = ['point_code', 'category_code'];

            const expectedResult = [{ error: `${error}`, value: '[object Object]', type: `Field doesn't exist`, point_code: 'Json', category_code: 'Test' }];
            const result = BusinessDataType.isJson(customer, fields, range, error, location);
            chai.expect(result).to.be.eql(expectedResult);
            chai.expect(result).to.be.an('array');
        });
    });
});

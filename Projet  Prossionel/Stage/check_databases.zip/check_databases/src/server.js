const { Server, ErrorHandler, logger, env } = require('nodelib');
const customerController = require('./controller/customer');
const controller = require('./controller/check');
const varEnv = [
    { key: 'APIUSER', mandatory: true, type: 'string' },
    { key: 'APIPASSWORD', mandatory: true, type: 'string' },
    { key: 'APIURL', mandatory: true, type: 'string' },
    { key: 'MAILER_URL', mandatory: true, type: 'string' },
    { key: 'DOCGEN_URL', mandatory: true, type: 'string' },
    { key: 'EMAILDEST', mandatory: true, type: 'string' },
    { key: 'DATAJSON', mandatory: true, type: 'string' },
];

const server = new Server();
server.initEnv(varEnv);
server.init();
const app = server.getApp();

app.use('/customers/', customerController);
app.use('/', controller);

server.listen();

const fs = require('fs');

exports.loadFileAsJson = function (filename) {
    try {
        console.log('load ' + filename);
        let rawdata = fs.readFileSync(filename);
        return JSON.parse(rawdata);
    } catch (error) {
        console.log(error);
        throw error;
    }
};

const { HttpApiV2, logger } = require('nodelib');
const http = new HttpApiV2();

exports.getData = async function (urlCustomers, jsonData) {
    return new Promise((resolve, reject) => {
        const waydata = path(jsonData);
        const routes = waydata.map((data) => data.route);
        const urlWithRoutes = routes.map((route) => `${urlCustomers}${route}`);
        const promises = urlWithRoutes.map((url) => http.get(url));
        Promise.all(promises)
            .then((responses) => {
                const results = [];
                for (let i = 0; i < responses.length; i++) {
                    const response = responses[i];
                    try {
                        const customers = response.data;
                        results.push(customers);
                    } catch {
                        results.push({ error: 'Failed to fetch customer data' });
                    }
                }
                resolve(results);
            })
            .catch((error) => {
                reject(error);
            });
    });
};
exports.getDataForCompare = async function (urlCustomers, jsonData) {
    return new Promise((resolve, reject) => {
        const waydata = path(jsonData);
        const verif = waydata.map((data) => data.range);
        const routes = verif.filter((entry) => entry.hasOwnProperty('route')).map((entry) => entry.route);
        if (routes.length === 0) {
            resolve(undefined);
        } else {
            const urlWithRoutes = routes.map((route) => `${urlCustomers}${route}`);
            const promises = urlWithRoutes.map((url) => http.get(url));
            Promise.all(promises)
                .then((responses) => {
                    const results = [];
                    for (let i = 0; i < responses.length; i++) {
                        const response = responses[i];
                        try {
                            const customers = response.data;
                            results.push(customers);
                        } catch {
                            results.push({ error: 'Failed to fetch customer data' });
                        }
                    }
                    resolve(results);
                })
                .catch((error) => {
                    reject(error);
                });
        }
    });
};

function path(jason) {
    const way = jason.toCheck;
    const result = [];
    for (let i = 0; i < way.length; i++) {
        const { fields, error, range, condition, route, role, location } = way[i];
        if (typeof fields === 'string') {
            const fieldss = fields.split('.');
            result.push({ fieldss, error, range, condition, route, role, location });
        } else {
            const fieldss = fields.map((item) => item.split('.'));
            for (let j = 0; j < fieldss.length; j++) {
                result.push({ fieldss: fieldss[j], error, range, condition, route, role, location });
            }
        }
    }
    return result;
}

exports.path = path;

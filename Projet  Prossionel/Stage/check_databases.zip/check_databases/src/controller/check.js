const { getData, getDataForCompare, path } = require('../tools/data');
const { processResults, filterResult } = require('../business/dataProcessing');
const { sendEmailWithTemplate } = require('../business/mail');
const { env } = require('nodelib');
const express = require('express');
const router = express.Router();
const { loadFileAsJson } = require('../tools/files');

router.get('', async (req, res, next) => {
    try {
        const jsonData = loadFileAsJson(env.DATAJSON);
        const waydata = path(jsonData);
        const url = env.APIURL;

        const responses = await getData(url, jsonData);
        const compares = await getDataForCompare(url, jsonData);

        const results = await processResults(responses, waydata, compares);
        const filter = filterResult(results);

        await sendEmailWithTemplate(filter);

        res.status(200).json({ message: 'E-mail envoyé avec succes' });
    } catch (error) {
        res.status(500).json({ error: 'Internal server error' + ' ' + error });
    }
});

module.exports = router;

const { getData, getDataForCompare, path } = require('../tools/data');
const { processResults, filterResult } = require('../business/dataProcessing');
const { sendEmailWithTemplateCustomer } = require('../business/mail');
const { env } = require('nodelib');
const express = require('express');
const router = express.Router();
const { loadFileAsJson } = require('../tools/files');

router.get('/:brand', async (req, res, next) => {
    try {
        const jsonData = loadFileAsJson(env.DATAJSON);
        const brand = req.params.brand;
        const urlCustomers = req.getCustomerUrl(brand);
        const waydata = path(jsonData);

        const responses = await getData(urlCustomers, jsonData);
        const compares = await getDataForCompare(urlCustomers, jsonData);
        const results = await processResults(responses, waydata, compares);
        const filter = filterResult(results);

        await sendEmailWithTemplateCustomer(brand, filter);

        res.status(200).json({ message: 'E-mail envoyé avec succes' });
    } catch (error) {
        res.status(500).json({ error: 'Internal server error' + ' ' + error });
    }
});

module.exports = router;

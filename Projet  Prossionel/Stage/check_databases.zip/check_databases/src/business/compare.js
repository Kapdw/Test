const { getFieldValue } = require('./helpers/common');

function compare(customers, fields, range, error, location, compare) {
    if (!customers || !customers.length || !compare || !compare.length) {
        return { error: `Invalid data` };
    }
    const result = [];
    let { fieldValues: fieldValuess, pointcodes: pointcodess, categorycodes: categorycodess, results: resultss } = getFieldValue(customers, fields, location[0], location[1], error);
    let { fieldValues: fieldValuesNew, pointcodes: pointcodesNew, categorycodes: categorycodesNew, results: resultsNew } = getFieldValue(compare, fields, undefined, undefined, error);
    if (resultss.length > 0) {
        result.push(...resultss);
    }
    if (resultsNew.length > 0) {
        result.push(...resultsNew);
    } else {
        for (let i = 0; i < fieldValuess.length; i++) {
            const fieldValue = fieldValuess[i];
            const pointcode = pointcodess[i];
            const categorycode = categorycodess[i];
            if (!fieldValuesNew.includes(fieldValue)) {
                result.push({
                    error: `${error}`,
                    value: `${fieldValue}`,
                    type: `This value don't exist in ${range.route}`,
                    point_code: `${pointcode}`,
                    category_code: `${categorycode}`,
                });
            }
        }
    }
    if (result.length > 0) {
        return result;
    }
    return { success: true };
}

module.exports = {
    compare,
};

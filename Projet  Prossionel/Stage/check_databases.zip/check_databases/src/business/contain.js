const { getFieldValue } = require('./helpers/common');

exports.contains = function (customers, fields, range, error, location) {
    if (!customers || !customers.length) {
        return { error: 'Invalid data' };
    }
    const result = [];
    let { fieldValues, pointcodes, categorycodes, results } = getFieldValue(customers, fields, location[0], location[1], error);
    if (results.length > 0) {
        result.push(...results);
    } else {
        for (let i = 0; i < fieldValues.length; i++) {
            const fieldValue = fieldValues[i];
            const pointcode = pointcodes[i];
            const categorycode = categorycodes[i];
            if (fieldValue.includes(range.caractere_not_present)) {
                result.push({ error: error, value: fieldValue, type: `does not contain ${range.caractere_not_present}`, point_code: pointcode, category_code: categorycode });
            }
        }
    }
    if (result.length > 0) {
        return result;
    }
    return { success: true };
};

exports.isEmpty = function (customers, fields, range, error, location) {
    if (!customers || !customers.length) {
        return { error: 'Invalid data' };
    }
    const result = [];
    let { fieldValues, pointcodes, categorycodes, results } = getFieldValue(customers, fields, location[0], location[1], error);
    if (results.length > 0) {
        result.push(...results);
    } else {
        for (let i = 0; i < fieldValues.length; i++) {
            const fieldValue = fieldValues[i];
            const pointcode = pointcodes[i];
            const categorycode = categorycodes[i];
            if (fieldValue == '') {
                result.push({ error: error, value: fieldValue, type: 'Value is empty', point_code: pointcode, category_code: categorycode });
            }
        }
    }
    if (result.length > 0) {
        return result;
    }
    return { success: true };
};

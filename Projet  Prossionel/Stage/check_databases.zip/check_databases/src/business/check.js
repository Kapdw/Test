const { getFieldValue } = require('./helpers/common');

function checkExists(customers, fields, range, error, location) {
    if (!customers || !customers.length) {
        return { error: `Invalid data`, value: `${customers}`, type: `${typeof customers}` };
    }
    const result = [];
    let { fieldValues, pointcodes, categorycodes, results } = getFieldValue(customers, fields, location[0], location[1], error);
    if (results.length > 0) {
        result.push(...results);
    } else {
        for (let i = 0; i < fieldValues.length; i++) {
            const fieldValue = fieldValues[i];
            const pointcode = pointcodes[i];
            const categorycode = categorycodes[i];
            // Vérification de la valeur du champ budget
            if (fieldValue === null || fieldValue === undefined) {
                result.push({ error: `${error}`, value: `${fieldValue}`, type: `Value do not exist type: ${typeof fieldValue}`, point_code: `${pointcode}`, category_code: `${categorycode}` });
            }
        }
    }
    // Si des erreurs ont été trouvées, on les renvoie, sinon on renvoie le succès
    if (result.length > 0) {
        return result;
    }
    return { success: true };
}

function checkBetween(customers, fields, range, error, location) {
    if (!customers || !customers.length) {
        return { error: `Invalid data`, value: `${customers}`, type: `${typeof customers}` };
    }
    const result = [];
    let { fieldValues, pointcodes, categorycodes, results } = getFieldValue(customers, fields, location[0], location[1], error);
    if (results.length > 0) {
        result.push(...results);
    } else {
        for (let i = 0; i < fieldValues.length; i++) {
            const fieldValue = fieldValues[i];
            const pointcode = pointcodes[i];
            const categorycode = categorycodes[i];
            // Vérification de la valeur du champ budget
            if (!fieldValue) {
                result.push({ error: `${error}`, value: `${fieldValue}`, type: `Value do not exist type: ${typeof fieldValue}`, point_code: `${pointcode}`, category_code: `${categorycode}` });
            } else if (typeof fieldValue !== 'number') {
                result.push({
                    error: `${error}`,
                    value: `${fieldValue}`,
                    type: `The expected value type is ${range.expectedtype} when it is found that the type is ${typeof fieldValue}`,
                    point_code: `${pointcode}`,
                    category_code: `${categorycode}`,
                });
            } else if (fieldValue < parseInt(range.low) || fieldValue > parseInt(range.high)) {
                result.push({
                    error: `${error}`,
                    value: `${fieldValue}`,
                    type: `Value is out of range, not between ${range.low} and ${range.high}`,
                    point_code: `${pointcode}`,
                    category_code: `${categorycode}`,
                });
            }
        }
    }
    // Si des erreurs ont été trouvées, on les renvoie, sinon on renvoie le succès
    if (result.length > 0) {
        return result;
    }
    return { success: true };
}

function checkValue(customers, fields, range, error, location) {
    if (!customers || !customers.length) {
        return { error: `Invalid data`, value: `${customers}`, type: `${typeof customers}` };
    }
    const result = [];
    let { fieldValues, pointcodes, categorycodes, results } = getFieldValue(customers, fields, location[0], location[1], error);
    if (results.length > 0) {
        result.push(...results);
    } else {
        for (let i = 0; i < fieldValues.length; i++) {
            const fieldValue = fieldValues[i];
            const pointcode = pointcodes[i];
            const categorycode = categorycodes[i];
            // Vérification de la valeur du champ budget
            if (fieldValue === null || fieldValue === undefined) {
                result.push({ error: `${error}`, value: `${fieldValue}`, type: `Value do not exist type: ${typeof fieldValue}`, point_code: `${pointcode}`, category_code: `${categorycode}` });
            } else if (!Array.isArray(range.exactValue)) {
                if (typeof fieldValue !== range.expectedtype || fieldValue != range.exactValue) {
                    result.push({
                        error: `${error}`,
                        value: `${fieldValue}`,
                        type: `Value do not match and/or the type didn't match, type expected: ${range.expectedtype}, type obtened: ${typeof fieldValue}`,
                        point_code: `${pointcode}`,
                        category_code: `${categorycode}`,
                    });
                }
            } else {
                if (typeof fieldValue !== range.expectedtype || !range.exactValue.includes(fieldValue)) {
                    result.push({
                        error: `${error}`,
                        value: `${fieldValue}`,
                        type: `Value do not match and/or the type didn't match, type expected: ${range.expectedtype}, type obtened: ${typeof fieldValue}`,
                        point_code: `${pointcode}`,
                        category_code: `${categorycode}`,
                    });
                }
            }
        }
    }
    if (result.length > 0) {
        return result;
    }
    return { success: true };
}

module.exports = {
    checkBetween,
    checkExists,
    checkValue,
};

const { getFieldValue } = require('./helpers/common');

function isNumber(customers, fields, range, error, location) {
    if (!customers || !customers.length) {
        return { error: 'Invalid data' };
    }
    const result = [];
    let { fieldValues, pointcodes, categorycodes, results } = getFieldValue(customers, fields, location[0], location[1], error);
    if (results.length > 0) {
        result.push(...results);
    } else {
        for (let i = 0; i < fieldValues.length; i++) {
            const fieldValue = fieldValues[i];
            const pointcode = pointcodes[i];
            const categorycode = categorycodes[i];
            // Vérification de la valeur du champ budget
            if (typeof fieldValue !== 'number' && typeof fieldValue !== 'string') {
                result.push({
                    error: `${error}`,
                    value: `${fieldValue}`,
                    type: `type mismatch received ${typeof fieldValue}, expected: ${range.expectedtype}`,
                    point_code: `${pointcode}`,
                    category_code: `${categorycode}`,
                });
            } else if (typeof fieldValue === 'string' && isNaN(parseInt(fieldValue))) {
                result.push({ error: `${error}`, value: `${fieldValue}`, type: `Invalid number conversion`, point_code: `${pointcode}`, category_code: `${categorycode}` });
            }
        }
    }
    if (result.length > 0) {
        return result;
    }

    return { success: true };
}

function isString(customers, fields, range, error, location) {
    if (!customers || !customers.length) {
        return { error: 'Invalid data' };
    }
    const result = [];
    let { fieldValues, pointcodes, categorycodes, results } = getFieldValue(customers, fields, location[0], location[1], error);
    if (results.length > 0) {
        result.push(...results);
    } else {
        for (let i = 0; i < fieldValues.length; i++) {
            const fieldValue = fieldValues[i];
            const pointcode = pointcodes[i];
            const categorycode = categorycodes[i];
            // Vérification de la valeur du champ budget
            if (typeof fieldValue !== 'string') {
                result.push({
                    error: `${error}`,
                    value: `${fieldValue}`,
                    type: `type mismatch received ${typeof fieldValue}, expected: ${range.expectedtype}`,
                    point_code: `${pointcode}`,
                    category_code: `${categorycode}`,
                });
            }
        }
    }
    if (result.length > 0) {
        return result;
    }
    return { success: true };
}

function isBoolean(customers, fields, range, error, location) {
    if (!customers || !customers.length) {
        return { error: 'Invalid data' };
    }
    const result = [];
    let { fieldValues, pointcodes, categorycodes, results } = getFieldValue(customers, fields, location[0], location[1], error);
    if (results.length > 0) {
        result.push(...results);
    } else {
        for (let i = 0; i < fieldValues.length; i++) {
            let fieldValue = fieldValues[i];
            const pointcode = pointcodes[i];
            const categorycode = categorycodes[i];
            // Vérification de la valeur du champ budget
            if (typeof fieldValue !== 'boolean' && typeof fieldValue !== 'string') {
                result.push({
                    error: `${error}`,
                    value: `${fieldValue}`,
                    type: `type mismatch received ${typeof fieldValue}, expected: ${range.expectedtype}`,
                    point_code: `${pointcode}`,
                    category_code: `${categorycode}`,
                });
            } else {
                if (typeof fieldValue === 'string') {
                    fieldValue = fieldValue.toLowerCase();
                    if (fieldValue !== 'true' && fieldValue !== 'false') {
                        result.push({ error: `${error}`, value: `${fieldValue}`, type: `Invalid boolean value`, point_code: `${pointcode}`, category_code: `${categorycode}` });
                    }
                }
            }
        }
    }
    if (result.length > 0) {
        return result;
    }
    return { success: true };
}

function isArray(customers, fields, range, error, location) {
    if (!customers || !customers.length) {
        return { error: 'Invalid data' };
    }
    const result = [];
    let { fieldValues, pointcodes, categorycodes, results } = getFieldValue(customers, fields, location[0], location[1], error);
    if (results.length > 0) {
        result.push(...results);
    } else {
        for (let i = 0; i < fieldValues.length; i++) {
            const fieldValue = fieldValues[i];
            const pointcode = pointcodes[i];
            const categorycode = categorycodes[i];
            // Vérification de la valeur du champ budget
            if (typeof fieldValue !== 'string' && !Array.isArray(fieldValue)) {
                result.push({
                    error: `${error}`,
                    value: `${fieldValue}`,
                    type: `type mismatch received ${typeof fieldValue}, expected: ${range.expectedtype}`,
                    point_code: `${pointcode}`,
                    category_code: `${categorycode}`,
                });
            } else {
                let parseValue;
                try {
                    parseValue = Array.isArray(fieldValue) ? fieldValue : JSON.parse(fieldValue);
                } catch {
                    result.push({ error: `${error}`, value: `${fieldValue}`, type: `Invalid array conversion`, point_code: `${pointcode}`, category_code: `${categorycode}` });
                    continue;
                }
                if (!Array.isArray(parseValue)) {
                    result.push({ error: `${error}`, value: `${fieldValue}`, type: `Invalid array conversion`, point_code: `${pointcode}`, category_code: `${categorycode}` });
                }
            }
        }
    }
    if (result.length > 0) {
        return result;
    }
    return { success: true };
}
function isJson(customers, fields, range, error, location) {
    if (!customers || !customers.length) {
        return { error: 'Invalid data' };
    }
    const result = [];
    let { fieldValues, pointcodes, categorycodes, results } = getFieldValue(customers, fields, location[0], location[1], error);
    if (results.length > 0) {
        result.push(...results);
    } else {
        for (let i = 0; i < fieldValues.length; i++) {
            const fieldValue = fieldValues[i];
            const pointcode = pointcodes[i];
            const categorycode = categorycodes[i];
            // Vérification de la valeur du champ budget
            if (typeof fieldValue !== 'object' && typeof fieldValue !== 'string') {
                result.push({
                    error: `${error}`,
                    value: `${fieldValue}`,
                    type: `type mismatch received ${typeof fieldValue}, expected: ${range.expectedtype}`,
                    point_code: `${pointcode}`,
                    category_code: `${categorycode}`,
                });
            } else if (typeof fieldValue === 'string') {
                try {
                    JSON.parse(fieldValue);
                } catch {
                    result.push({ error: `${error}`, value: `${fieldValue}`, type: `Invalid JSON format`, point_code: `${pointcode}`, category_code: `${categorycode}` });
                }
            } else {
                try {
                    JSON.parse(JSON.stringify(fieldValue));
                } catch {
                    result.push({ error: `${error}`, value: `${fieldValue}`, type: `Invalid JSON format`, point_code: `${pointcode}`, category_code: `${categorycode}` });
                }
            }
        }
    }
    if (result.length > 0) {
        return result;
    }
    return { success: true };
}

module.exports = {
    isJson,
    isNumber,
    isString,
    isBoolean,
    isArray,
};

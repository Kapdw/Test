const { compare } = require('./compare');
const { contains, isEmpty } = require('./contain');
const { isJson, isNumber, isString, isBoolean, isArray } = require('./dataType');
const { checkBetween, checkExists, checkValue } = require('./check');

async function processResponse(response, waydata, compared) {
    try {
        const customers = response.data;
        const { condition, fieldss, range, error, location, role } = waydata;
        const conditions = {
            between: checkBetween,
            exists: checkExists,
            json: isJson,
            number: isNumber,
            string: isString,
            boolean: isBoolean,
            array: isArray,
            equal: checkValue,
            contain: contains,
            empty: isEmpty,
            compare: compare,
        };
        if (compared !== undefined) {
            const comparedd = compared.data;

            if (conditions.hasOwnProperty(condition)) {
                const func = conditions[condition];
                const result = func(customers, fieldss, range, error, location, comparedd);
                return { result, role };
            } else {
                throw new Error(`Invalid condition: ${condition}`);
            }
        } else {
            if (conditions.hasOwnProperty(condition)) {
                const func = conditions[condition];
                const result = func(customers, fieldss, range, error, location);
                return { result, role };
            } else {
                throw new Error(`Invalid condition: ${condition}`);
            }
        }
    } catch (error) {
        // Gestion des erreurs lors de la vérification des données
        return { error: error.message };
    }
}

function filterResult(results) {
    const filteredResults = results.flat().flatMap((result) => {
        if (result.result && Array.isArray(result.result) && (!result.result.hasOwnProperty('success') || result.result.success !== true)) {
            return result.result.map((item) => {
                const error = item.error || '';
                const value = item.value || '';
                const type = item.type || '';
                const point_code = item.point_code || '';
                const category_code = item.category_code || '';

                return {
                    error: error,
                    point_code: point_code,
                    category_code: category_code,
                    role: result.role,
                    value: value,
                    type: type,
                };
            });
        } else if (result.error !== undefined) {
            return {
                error: result.error || '',
                role: result.role || '',
            };
        } else if (result.hasOwnProperty('result') && result.result.hasOwnProperty('error')) {
            return {
                error: result.result.error,
                role: result.role,
            };
        } else if (Array.isArray(result) && result.length > 0 && result[0].error !== undefined) {
            return result.map((item) => {
                return {
                    error: item.error || '',
                    role: item.role || '',
                };
            });
        }
        return [];
    });
    const tableResult = filteredResults.map((item) => {
        return {
            point_code: item.point_code,
            category_code: item.category_code,
            role: item.role,
            error: item.error,
            value: item.value,
            type: item.type,
        };
    });
    return tableResult;
}
async function processResults(responses, waydata, compares) {
    return Promise.all(
        responses.map((response, i) => {
            if (Array.isArray(compares) && compares.length > 0) {
                return Promise.all(compares.map((compare) => processResponse(response, waydata[i], compare)));
            } else {
                return processResponse(response, waydata[i]);
            }
        })
    );
}

module.exports = {
    filterResult,
    processResponse,
    processResults,
};

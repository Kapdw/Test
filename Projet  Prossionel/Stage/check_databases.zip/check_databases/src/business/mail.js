const { HttpApiV2, logger, env } = require('nodelib');
const http = new HttpApiV2();


async function sendMailWithTemplate({ emailDest, emailFrom, template, data, attachmentName = null, attachmentContent = null }) {
    try {
        const urlDocGen = env.DOCGEN_URL.concat('/email/', template);
        const bodyData = {
            data: {
                brand: data.brand,
                result: data.result,
            },
        };

        const mailRes = await http.post(urlDocGen, bodyData);
        const urlMail = env.MAILER_URL.concat('/mail');

        let attachments = [];
        if (attachmentName && attachmentContent) {
            attachments.push({
                filename: attachmentName,
                content: attachmentContent,
            });
        }

        const datamail = {
            from: emailFrom,
            dest: emailDest,
            attachment: attachments,
            subject: `Résultats de la vérification des données ${data.brand !== undefined ? data.brand : ''}`,
            text: mailRes.data.text,
            html: mailRes.data.html,
            encode: {},
        };
        const response = await http.post(urlMail, datamail);
        logger.info('request to ' + urlMail + ' sent :' + response.status);
        return response;
    } catch (e) {
        throw e;
    }
}

async function sendEmailWithTemplateCustomer(brand, filter) {
    const template = 'checkDatabases';
    const emailDest = process.env.EMAILDEST;
    const emailFrom = 'support@adcleek.com';
    const data = {
        brand: brand,
        result: Array.from(filter),
    };
    await sendMailWithTemplate({ emailDest, emailFrom, template, data });
}

async function sendEmailWithTemplate(filter) {
    const template = 'checkDatabases';
    const emailDest = env.EMAILDEST;
    const emailFrom = 'support@adcleek.com';
    const data = {
        result: Array.from(filter),
    };
    await sendMailWithTemplate({ emailDest, emailFrom, template, data });
}

module.exports = {
    
    sendMailWithTemplate,
    sendEmailWithTemplate,
    sendEmailWithTemplateCustomer,
};

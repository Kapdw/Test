function getFieldValue(customers, fields, pc, cc, error) {
    const results = [];
    let fieldValues = [];
    let pointcodes = [];
    let categorycodes = [];
    for (let i = 0; i < customers.length; i++) {
        const customer = customers[i];
        let fieldValue = customer;
        // Récupération de point_code ainsi que de la category_code
        let { pointcode, warning } = getLocationFirstValue(fieldValue, pc, error);
        results.push(...warning);
        let { categorycode, warnings } = getLocationSecondValue(fieldValue, cc, error);
        results.push(...warnings);
        // Parcours des champs dans fields
        for (let j = 0; j < fields.length; j++) {
            const fieldObj = fields[j];
            // Vérification si le champ existe dans le client actuel
            if (!fieldValue || !fieldValue.hasOwnProperty(fieldObj)) {
                results.push({
                    error: `${error}`,
                    value: fieldValue !== undefined ? `${fieldValue}` : 'unknown',
                    type: `Field doesn't exist`,
                    point_code: `${pointcode}`,
                    category_code: `${categorycode}`,
                });
            } else {
                // Récupération de la valeur du champ
                fieldValue = fieldValue[fieldObj];
            }
        }
        fieldValues.push(fieldValue);
        pointcodes.push(pointcode);
        categorycodes.push(categorycode);
    }

    return { fieldValues, pointcodes, categorycodes, results };
}

function getLocationFirstValue(fieldValue, point_code, error) {
    const warning = [];
    let pointcode;
    if (point_code === undefined) {
        pointcode = '';
        return { pointcode, warning };
    }
    let pc = point_code.split('.');
    for (let i = 0; i < pc.length; i++) {
        const pcObj = pc[i];
        if (!fieldValue || !fieldValue.hasOwnProperty(pcObj)) {
            warning.push({ error: `${error}`, value: pointcode ? `${pointcode}` : 'unknown', type: `Field doesn't exist` });
        } else {
            pointcode = fieldValue[pcObj];
        }
    }
    return { pointcode, warning };
}

function getLocationSecondValue(fieldValue, category_code, error) {
    const warnings = [];
    let categorycode;
    if (category_code === undefined) {
        categorycode = '';
        return { categorycode, warnings };
    }
    let cc = category_code.split('.');
    for (let i = 0; i < cc.length; i++) {
        const ccObj = cc[i];
        if (!fieldValue || !fieldValue.hasOwnProperty(ccObj)) {
            warnings.push({ error: `${error}`, value: categorycode ? `${categorycode}` : 'unknown', type: `Field doesn't exist` });
        } else {
            categorycode = fieldValue[ccObj];
        }
    }
    return { categorycode, warnings };
}

module.exports = {
    getFieldValue,
    getLocationFirstValue,
    getLocationSecondValue,
};
